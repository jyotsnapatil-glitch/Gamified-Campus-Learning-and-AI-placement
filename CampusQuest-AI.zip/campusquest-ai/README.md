# CampusQuest AI

Gamified campus learning and AI placement portal. Students learn, take assessments, earn XP and badges, get
AI career guidance and apply for campus jobs. Recruiters post jobs and review candidates. Admins approve recruiters and
manage content.

> **Project status:** work in progress. The Angular frontend runs on mock data and is tested. The ASP.NET Core backend
> (authentication and database model) is written but has not been compiled or run yet. See [docs/ROADMAP.md](docs/ROADMAP.md).

## Repository layout
```
frontend/   Angular 21 app (student shell and dashboard, public pages) with mock services
backend/    ASP.NET Core (.NET 10) API, EF Core + SQL Server, Identity authentication, tests
docs/       architecture and roadmap
.github/    CI workflow (frontend tests and build, backend build and tests)
```

## Quick start

### Frontend (works on its own, no backend needed)
```bash
cd frontend
npm install --legacy-peer-deps
npm start          # http://localhost:4200
```
Open http://localhost:4200/login and use **Preview the app (demo mode)**. Requires Node 22.12 or newer.
Details: [frontend/README.md](frontend/README.md)

### Backend
Requires the .NET 10 SDK and SQL Server (Docker or LocalDB).
```bash
cd backend
# see backend/README.md for secrets, the first migration and running the API
dotnet test
```
Details: [backend/README.md](backend/README.md)

## Tests
| Part | Command | Notes |
|---|---|---|
| Frontend | `cd frontend && npm test -- --watch=false` | 49 tests |
| Backend | `cd backend && dotnet test` | unit and integration tests, in-memory database |

## What is real and what is demo
- The dashboard, notifications and role switcher use clearly labelled demo data. Sign-in and registration are never faked
  in the frontend until it is connected to the API.
- The backend implements registration, login, refresh-token rotation, logout, recruiter approval and an audit log. All
  other tables exist in the database model but have no endpoints yet.

## Security notes
- Never commit secrets. The backend reads the JWT key, connection string and demo password from user-secrets or
  environment variables; `.env` is git-ignored.
- Demo accounts are created only in Development and only when `Seed:DemoPassword` is set.
