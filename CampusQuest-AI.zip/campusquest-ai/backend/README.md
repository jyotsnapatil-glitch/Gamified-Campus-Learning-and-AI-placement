# CampusQuest AI — backend (Phase 3): database and authentication

ASP.NET Core Web API on **.NET 10 (LTS)** with SQL Server, Entity Framework Core and ASP.NET Core Identity.
(.NET 8 reaches end of support on 10 November 2026, so this project targets .NET 10, supported until November 2028.)

## Status — read this first
- **This code has not been compiled or run.** The environment it was written in has no .NET SDK, so there has been no
  `dotnet build`, no `dotnet test` and no migration run. Expect to fix a few small compile errors on your first build.
  Send me the exact error text and I'll fix it.
- **The EF Core migration is not generated yet.** You create it with one command (below).
- The Angular frontend is not connected to this API yet (that is the next step).

## What is implemented
- Solution layout: `Domain` (entities), `Application` (DTOs, rules, interfaces), `Infrastructure` (EF Core, Identity, tokens), `Api` (controllers), `Tests`
- Full MVP database model (about 37 tables) with keys, unique constraints, indexes, timestamps, row versions and restricted deletes
- **Auth**
  - Register as Student or Recruiter. Admin can never be chosen (server-side check, tested)
  - Recruiters cannot sign in until an admin approves them
  - Login returns a 15-minute JWT access token in the JSON body
  - The refresh token is an opaque random value stored **hashed** in the database and sent **only** in an
    `HttpOnly`, `SameSite=Strict`, path-restricted cookie
  - Refresh rotates the token; reusing an old one revokes the whole session
  - Logout revokes the token; account lockout after 5 failed attempts; the same error for wrong password and unknown user
  - Rate limiting on auth endpoints (10 per minute per IP, configurable)
- Admin endpoints to list, approve and reject recruiters (with audit log and notification)
- Audit log entries for register, login, failed login, refresh reuse and recruiter decisions (never passwords or tokens)
- Deterministic, idempotent seed data: roles, 16 skills, 5 badges, 3 missions
- Demo accounts for **Development only**, and only if you set a demo password (no credentials in the repo)
- Tests: password and registration rules, token creation and validation, and API integration tests (in-memory database)

## Prerequisites
- .NET 10 SDK
- SQL Server: Docker (`docker compose up -d`) or Windows LocalDB
- EF Core CLI: `dotnet tool install --global dotnet-ef`

## Setup
Run these from the `backend` folder of the repository.
```bash
cd backend

# 1. Start SQL Server (skip if you use LocalDB)
cp .env.example .env          # then edit the SA password
docker compose up -d

# 2. Secrets (stored outside the repo)
cd src/CampusQuest.Api
dotnet user-secrets set "Jwt:Key" "$(openssl rand -base64 48)"          # any random string of 32+ characters
dotnet user-secrets set "ConnectionStrings:Default" "Server=localhost,1433;Database=CampusQuest;User Id=sa;Password=<your SA password>;TrustServerCertificate=True"
dotnet user-secrets set "Seed:DemoPassword" "Demo-Passw0rd1"            # 8+ chars with a letter and a number
cd ../..
# LocalDB instead of Docker:  Server=(localdb)\MSSQLLocalDB;Database=CampusQuest;Trusted_Connection=True;TrustServerCertificate=True

# 3. Create the first migration (once)
dotnet ef migrations add InitialCreate --project src/CampusQuest.Infrastructure --startup-project src/CampusQuest.Api --output-dir Persistence/Migrations

# 4. Run (in Development this applies migrations and seeds data on startup)
dotnet run --project src/CampusQuest.Api
```
Open http://localhost:5080/swagger. The API listens on http://localhost:5080.

Demo accounts (password = your `Seed:DemoPassword`): `admin@campusquest.local`, `recruiter@campusquest.local`, `student@campusquest.local`.

## Try it
```bash
# register a student
curl -s -X POST http://localhost:5080/api/auth/register -H "Content-Type: application/json" \
  -d '{"fullName":"Asha Rao","email":"asha@example.com","password":"Passw0rd1","role":"Student"}'

# log in (-c saves the refresh cookie)
curl -s -c cookies.txt -X POST http://localhost:5080/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"asha@example.com","password":"Passw0rd1"}'

# call a protected endpoint with the accessToken from the response
curl -s http://localhost:5080/api/auth/me -H "Authorization: Bearer <accessToken>"

# refresh (uses the cookie, rotates it)
curl -s -b cookies.txt -c cookies.txt -X POST http://localhost:5080/api/auth/refresh
```
Swagger UI cannot send the bearer token yet (no Authorize button), so use curl for protected endpoints.

## Run the tests
```bash
dotnet test
```
Integration tests use an in-memory database, so no SQL Server is needed.

## Endpoints
| Method and path | Access |
|---|---|
| `POST /api/auth/register` | anonymous |
| `POST /api/auth/login` | anonymous |
| `POST /api/auth/refresh` | cookie |
| `POST /api/auth/logout` | cookie |
| `GET /api/auth/me` | signed in |
| `GET /api/admin/recruiters?status=pending` | Admin |
| `POST /api/admin/recruiters/{userId}/approve` and `/reject` | Admin |
| `GET /health` | anonymous |

## Configuration
| Setting | Purpose |
|---|---|
| `Jwt:Key` | signing key, 32+ chars (user-secrets locally, Key Vault in Azure) |
| `ConnectionStrings:Default` | SQL Server connection string |
| `Database:MigrateOnStartup`, `Database:SeedOnStartup` | on in Development, off elsewhere (apply migrations in your deployment pipeline) |
| `Auth:CookieSecure` | `true` everywhere except local HTTP development |
| `Cors:Origins` | allowed SPA origins (default `http://localhost:4200`) |
| `RateLimiting:AuthPermitPerMinute` | auth endpoint limit |
| `Seed:DemoPassword` | enables demo accounts in Development |

## Known limitations
- Email verification and password reset are not implemented (they need an email provider)
- Cookie security: `SameSite=Strict` needs the SPA and API on the same site. Cross-site hosting needs a different design (for example a backend-for-frontend)
- Swagger UI has no bearer-token button yet
- Resume storage, AI services, XP rules and the learning, placement and notification endpoints come in later phases. Their tables already exist.

## Troubleshooting
- `Jwt:Key is missing...` on start or when running `dotnet ef`: set the user-secret above
- `connectionString cannot be empty`: set `ConnectionStrings:Default`
- Compile error mentioning `IDbContextOptionsConfiguration` in the tests: it lives in `Microsoft.EntityFrameworkCore.Infrastructure`; tell me the exact message
- `.slnx` not recognised: run `dotnet new sln` and `dotnet sln add` for each project, or open the projects directly
