using System.Security.Claims;
using CampusQuest.Application.Common;
using Microsoft.AspNetCore.Mvc;

namespace CampusQuest.Api;

public static class ApiExtensions
{
    /// <summary>Translates a failed service result into a consistent RFC 7807 problem response.</summary>
    public static IActionResult ToProblem<T>(this ServiceResult<T> result, ControllerBase controller)
    {
        switch (result.Error)
        {
            case ErrorKind.Validation:
                return controller.ValidationProblem(new ValidationProblemDetails(
                    result.ValidationErrors!.ToDictionary(e => e.Key, e => e.Value)));
            case ErrorKind.Unauthorized:
                return controller.Problem(title: "Unauthorized", detail: result.Message, statusCode: StatusCodes.Status401Unauthorized);
            case ErrorKind.Forbidden:
                return controller.Problem(title: "Forbidden", detail: result.Message, statusCode: StatusCodes.Status403Forbidden);
            case ErrorKind.NotFound:
                return controller.Problem(title: "Not found", detail: result.Message, statusCode: StatusCodes.Status404NotFound);
            case ErrorKind.Conflict:
                return controller.Problem(title: "Conflict", detail: result.Message, statusCode: StatusCodes.Status409Conflict);
            case ErrorKind.TooManyRequests:
                return controller.Problem(title: "Too many requests", detail: result.Message, statusCode: StatusCodes.Status429TooManyRequests);
            default:
                return controller.Problem(statusCode: StatusCodes.Status500InternalServerError);
        }
    }

    public static Guid GetUserId(this ClaimsPrincipal user)
    {
        var sub = user.FindFirst("sub")?.Value;
        return Guid.TryParse(sub, out var id) ? id : throw new InvalidOperationException("Missing or invalid 'sub' claim.");
    }
}
