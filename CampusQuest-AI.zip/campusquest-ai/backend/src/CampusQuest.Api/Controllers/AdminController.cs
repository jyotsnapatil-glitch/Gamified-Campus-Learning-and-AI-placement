using CampusQuest.Application.Auth;
using CampusQuest.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CampusQuest.Api.Controllers;

[ApiController]
[Route("api/admin")]
[Authorize(Roles = AppRoles.Admin)]
public class AdminController : ControllerBase
{
    private readonly IRecruiterApprovalService _recruiters;

    public AdminController(IRecruiterApprovalService recruiters) => _recruiters = recruiters;

    /// <summary>Lists recruiters by approval status (default: pending).</summary>
    [HttpGet("recruiters")]
    [ProducesResponseType<IReadOnlyList<RecruiterDto>>(StatusCodes.Status200OK)]
    public async Task<IActionResult> ListRecruiters([FromQuery] ApprovalStatus status = ApprovalStatus.Pending, CancellationToken ct = default) =>
        Ok(await _recruiters.ListAsync(status, ct));

    [HttpPost("recruiters/{userId:guid}/approve")]
    [ProducesResponseType<RecruiterDto>(StatusCodes.Status200OK)]
    public async Task<IActionResult> Approve(Guid userId, CancellationToken ct)
    {
        var result = await _recruiters.DecideAsync(userId, approve: true, User.GetUserId(), ct);
        return result.Succeeded ? Ok(result.Value) : result.ToProblem(this);
    }

    [HttpPost("recruiters/{userId:guid}/reject")]
    [ProducesResponseType<RecruiterDto>(StatusCodes.Status200OK)]
    public async Task<IActionResult> Reject(Guid userId, CancellationToken ct)
    {
        var result = await _recruiters.DecideAsync(userId, approve: false, User.GetUserId(), ct);
        return result.Succeeded ? Ok(result.Value) : result.ToProblem(this);
    }
}
