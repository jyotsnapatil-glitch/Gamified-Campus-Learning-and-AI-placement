using CampusQuest.Application.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace CampusQuest.Api.Controllers;

[ApiController]
[Route("api/auth")]
[EnableRateLimiting("auth")]
public class AuthController : ControllerBase
{
    /// <summary>The refresh token lives only in this HttpOnly cookie, never in JavaScript-readable storage.</summary>
    public const string RefreshCookie = "cq_refresh";

    private readonly IAuthService _auth;
    private readonly IConfiguration _config;

    public AuthController(IAuthService auth, IConfiguration config)
    {
        _auth = auth;
        _config = config;
    }

    [HttpPost("register")]
    [AllowAnonymous]
    [ProducesResponseType<RegisterResponse>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register(RegisterRequest request, CancellationToken ct)
    {
        var result = await _auth.RegisterAsync(request, ct);
        return result.Succeeded ? StatusCode(StatusCodes.Status201Created, result.Value) : result.ToProblem(this);
    }

    [HttpPost("login")]
    [AllowAnonymous]
    [ProducesResponseType<AuthResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> Login(LoginRequest request, CancellationToken ct)
    {
        var result = await _auth.LoginAsync(request, ct);
        if (!result.Succeeded) return result.ToProblem(this);
        WriteRefreshCookie(result.Value!.RefreshToken, result.Value.RefreshExpiresUtc);
        return Ok(result.Value.Response);
    }

    [HttpPost("refresh")]
    [AllowAnonymous]
    [ProducesResponseType<AuthResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Refresh(CancellationToken ct)
    {
        var result = await _auth.RefreshAsync(Request.Cookies[RefreshCookie], ct);
        if (!result.Succeeded)
        {
            ClearRefreshCookie();
            return result.ToProblem(this);
        }
        WriteRefreshCookie(result.Value!.RefreshToken, result.Value.RefreshExpiresUtc);
        return Ok(result.Value.Response);
    }

    [HttpPost("logout")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Logout(CancellationToken ct)
    {
        await _auth.LogoutAsync(Request.Cookies[RefreshCookie], ct);
        ClearRefreshCookie();
        return NoContent();
    }

    [HttpGet("me")]
    [Authorize]
    [ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Me(CancellationToken ct)
    {
        var result = await _auth.GetCurrentUserAsync(User.GetUserId(), ct);
        return result.Succeeded ? Ok(result.Value) : result.ToProblem(this);
    }

    private CookieOptions BuildCookie(DateTime? expiresUtc) => new()
    {
        HttpOnly = true,
        Secure = _config.GetValue("Auth:CookieSecure", true),
        SameSite = SameSiteMode.Strict, // the SPA and API must be same-site (same registrable domain)
        Path = "/api/auth",             // the browser only sends it to the auth endpoints
        IsEssential = true,
        Expires = expiresUtc is null ? null : new DateTimeOffset(DateTime.SpecifyKind(expiresUtc.Value, DateTimeKind.Utc)),
    };

    private void WriteRefreshCookie(string token, DateTime expiresUtc) =>
        Response.Cookies.Append(RefreshCookie, token, BuildCookie(expiresUtc));

    private void ClearRefreshCookie() =>
        Response.Cookies.Delete(RefreshCookie, BuildCookie(null));
}
