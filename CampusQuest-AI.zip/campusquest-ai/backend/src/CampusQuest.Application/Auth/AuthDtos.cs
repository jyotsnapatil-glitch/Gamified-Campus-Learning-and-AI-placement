namespace CampusQuest.Application.Auth;

public record RegisterRequest(string FullName, string Email, string Password, string Role, string? Company);
public record RegisterResponse(string Message, bool RequiresApproval);

public record LoginRequest(string Email, string Password);

public record UserDto(Guid Id, string FullName, string Email, string Role);

/// <summary>What the browser receives. The refresh token is NOT here: it travels only in an HttpOnly cookie.</summary>
public record AuthResponse(string AccessToken, int ExpiresInSeconds, UserDto User);

/// <summary>Returned by the service; the controller puts the refresh token into the cookie.</summary>
public record LoginResult(AuthResponse Response, string RefreshToken, DateTime RefreshExpiresUtc);
