using CampusQuest.Application.Common;

namespace CampusQuest.Application.Auth;

public interface IAuthService
{
    Task<ServiceResult<RegisterResponse>> RegisterAsync(RegisterRequest request, CancellationToken ct = default);
    Task<ServiceResult<LoginResult>> LoginAsync(LoginRequest request, CancellationToken ct = default);
    Task<ServiceResult<LoginResult>> RefreshAsync(string? refreshToken, CancellationToken ct = default);
    Task LogoutAsync(string? refreshToken, CancellationToken ct = default);
    Task<ServiceResult<UserDto>> GetCurrentUserAsync(Guid userId, CancellationToken ct = default);
}
