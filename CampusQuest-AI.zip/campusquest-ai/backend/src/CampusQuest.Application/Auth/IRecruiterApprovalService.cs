using CampusQuest.Application.Common;
using CampusQuest.Domain;

namespace CampusQuest.Application.Auth;

public record RecruiterDto(Guid UserId, string FullName, string Email, string Company, string Status, DateTime RequestedUtc, DateTime? DecidedUtc);

public interface IRecruiterApprovalService
{
    Task<IReadOnlyList<RecruiterDto>> ListAsync(ApprovalStatus status, CancellationToken ct = default);
    Task<ServiceResult<RecruiterDto>> DecideAsync(Guid recruiterUserId, bool approve, Guid adminUserId, CancellationToken ct = default);
}
