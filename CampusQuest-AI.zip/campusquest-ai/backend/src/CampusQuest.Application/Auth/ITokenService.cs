namespace CampusQuest.Application.Auth;

public record AccessToken(string Value, DateTime ExpiresUtc);

public interface ITokenService
{
    AccessToken CreateAccessToken(Guid userId, string email, string fullName, string role);

    /// <summary>A new random refresh token (raw value, to be sent to the client once).</summary>
    string GenerateRefreshToken();

    /// <summary>Deterministic hash used to store and look up refresh tokens.</summary>
    string HashRefreshToken(string rawToken);

    TimeSpan RefreshTokenLifetime { get; }
}
