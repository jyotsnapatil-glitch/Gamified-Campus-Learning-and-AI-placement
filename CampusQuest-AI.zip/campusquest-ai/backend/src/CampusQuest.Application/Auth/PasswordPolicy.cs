namespace CampusQuest.Application.Auth;

/// <summary>Server-side password rules. Identity also enforces length and digit; this adds the letter rule.</summary>
public static class PasswordPolicy
{
    public const int MinLength = 8;

    public static IReadOnlyList<string> Validate(string? password)
    {
        var errors = new List<string>();
        var p = password ?? "";
        if (p.Length < MinLength) errors.Add($"Use at least {MinLength} characters.");
        if (!p.Any(char.IsLetter)) errors.Add("Include at least one letter.");
        if (!p.Any(char.IsDigit)) errors.Add("Include at least one number.");
        return errors;
    }
}
