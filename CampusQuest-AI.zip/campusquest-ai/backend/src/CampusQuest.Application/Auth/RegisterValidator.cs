using CampusQuest.Domain;

namespace CampusQuest.Application.Auth;

public static class RegisterValidator
{
    /// <summary>Returns field errors, empty when the request is valid. Role is normalised separately.</summary>
    public static Dictionary<string, string[]> Validate(RegisterRequest r)
    {
        var errors = new Dictionary<string, string[]>();

        if (string.IsNullOrWhiteSpace(r.FullName) || r.FullName.Trim().Length < 2)
            errors["fullName"] = new[] { "Enter your full name." };

        if (!IsPlausibleEmail(r.Email))
            errors["email"] = new[] { "Enter a valid email address." };

        var pw = PasswordPolicy.Validate(r.Password);
        if (pw.Count > 0) errors["password"] = pw.ToArray();

        if (NormalizeRole(r.Role) is null)
            errors["role"] = new[] { "Choose Student or Recruiter." };
        else if (NormalizeRole(r.Role) == AppRoles.Recruiter && string.IsNullOrWhiteSpace(r.Company))
            errors["company"] = new[] { "Enter your company name." };

        return errors;
    }

    /// <summary>Maps user input to a role name, or null if it is not self-registrable (Admin is never allowed).</summary>
    public static string? NormalizeRole(string? input) =>
        AppRoles.SelfRegistrable.FirstOrDefault(r => string.Equals(r, input?.Trim(), StringComparison.OrdinalIgnoreCase));

    private static bool IsPlausibleEmail(string? email)
    {
        if (string.IsNullOrWhiteSpace(email) || email.Length > 254) return false;
        var at = email.IndexOf('@');
        return at > 0 && at == email.LastIndexOf('@') && email.IndexOf('.', at) > at + 1 && !email.Contains(' ') && !email.EndsWith('.');
    }
}
