namespace CampusQuest.Application.Common;

public enum ErrorKind
{
    None = 0,
    Validation,
    Unauthorized,
    Forbidden,
    NotFound,
    Conflict,
    TooManyRequests,
}

/// <summary>Result of a service call. Controllers translate it into HTTP responses.</summary>
public class ServiceResult<T>
{
    public T? Value { get; private init; }
    public ErrorKind Error { get; private init; }
    public string? Message { get; private init; }
    public IReadOnlyDictionary<string, string[]>? ValidationErrors { get; private init; }

    public bool Succeeded => Error == ErrorKind.None;

    public static ServiceResult<T> Ok(T value) => new() { Value = value };

    public static ServiceResult<T> Fail(ErrorKind kind, string message) =>
        new() { Error = kind, Message = message };

    public static ServiceResult<T> Invalid(IDictionary<string, string[]> errors) =>
        new()
        {
            Error = ErrorKind.Validation,
            Message = "One or more validation errors occurred.",
            ValidationErrors = new Dictionary<string, string[]>(errors),
        };
}
