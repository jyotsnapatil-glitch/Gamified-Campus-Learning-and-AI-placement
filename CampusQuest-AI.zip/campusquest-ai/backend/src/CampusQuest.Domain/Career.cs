namespace CampusQuest.Domain;

public class Resume : Entity
{
    public Guid UserId { get; set; }
    public string BlobName { get; set; } = "";
    public string OriginalFileName { get; set; } = "";
    public string ContentHash { get; set; } = "";
    public DateTime DeleteAfterUtc { get; set; }
}

public class ResumeAnalysis : Entity
{
    public Guid ResumeId { get; set; }
    public Resume Resume { get; set; } = null!;
    public Guid? JobId { get; set; }
    public Job? Job { get; set; }
    public string? TargetRole { get; set; }
    public int MatchScore { get; set; }
    public string ResultJson { get; set; } = "{}";
    public AiSource Source { get; set; }
}

public class Roadmap : Entity
{
    public Guid UserId { get; set; }
    public string TargetRole { get; set; } = "";
    public AiSource Source { get; set; }
    public RoadmapStatus Status { get; set; } = RoadmapStatus.Active;
    public List<RoadmapStep> Steps { get; set; } = new();
}

public class RoadmapStep : Entity
{
    public Guid RoadmapId { get; set; }
    public Roadmap Roadmap { get; set; } = null!;
    public int Order { get; set; }
    public string Title { get; set; } = "";
    public string Reason { get; set; } = "";
    public string? Prerequisites { get; set; }
    public int EstimatedDays { get; set; }
    public StepStatus Status { get; set; } = StepStatus.NotStarted;
    public Guid? CourseId { get; set; }
    public Course? Course { get; set; }
}
