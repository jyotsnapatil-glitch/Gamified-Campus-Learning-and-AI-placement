namespace CampusQuest.Domain;

public abstract class Entity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CreatedUtc { get; set; }
    public DateTime UpdatedUtc { get; set; }
}

public static class AppRoles
{
    public const string Student = "Student";
    public const string Recruiter = "Recruiter";
    public const string Admin = "Admin";

    public static readonly string[] All = { Student, Recruiter, Admin };

    /// <summary>Roles a person may choose when registering. Admin is deliberately absent.</summary>
    public static readonly string[] SelfRegistrable = { Student, Recruiter };
}

public enum ApprovalStatus { Pending = 0, Approved = 1, Rejected = 2 }
public enum Difficulty { Beginner = 0, Intermediate = 1, Advanced = 2 }
public enum SkillLevel { Beginner = 0, Intermediate = 1, Advanced = 2 }
public enum EvidenceType { SelfDeclared = 0, QuizAssessed = 1, CodingChallenge = 2, CourseCompletion = 3, ExternallyVerified = 4 }
public enum MissionPeriod { Daily = 0, Weekly = 1 }
public enum AiSource { Live = 0, Demo = 1 }
public enum JobStatus { Draft = 0, Published = 1, Closed = 2 }
public enum ApplicationStatus { Applied = 0, UnderReview = 1, Shortlisted = 2, InterviewScheduled = 3, Selected = 4, Rejected = 5, Withdrawn = 6 }
public enum RoadmapStatus { Active = 0, Completed = 1, Archived = 2 }
public enum StepStatus { NotStarted = 0, InProgress = 1, Done = 2 }
public enum InterviewMode { Online = 0, InPerson = 1 }
