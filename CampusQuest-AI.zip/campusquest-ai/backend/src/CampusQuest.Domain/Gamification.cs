namespace CampusQuest.Domain;

/// <summary>
/// Append-only XP ledger. A unique index on (UserId, SourceType, SourceId) makes awards idempotent.
/// Total XP, level and leaderboards are derived from this table, never stored separately.
/// </summary>
public class XpTransaction : Entity
{
    public Guid UserId { get; set; }
    public int Amount { get; set; }
    public string SourceType { get; set; } = "";
    public Guid SourceId { get; set; }
}

public class Badge : Entity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
}

public class StudentBadge : Entity
{
    public Guid UserId { get; set; }
    public Guid BadgeId { get; set; }
    public Badge Badge { get; set; } = null!;
    public DateTime AwardedUtc { get; set; }
}

public class Mission : Entity
{
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public MissionPeriod Period { get; set; }
    public int TargetCount { get; set; }
    public int XpReward { get; set; }
    public bool IsActive { get; set; } = true;
}

public class MissionProgress : Entity
{
    public Guid UserId { get; set; }
    public Guid MissionId { get; set; }
    public Mission Mission { get; set; } = null!;
    public DateTime PeriodStartUtc { get; set; }
    public int Count { get; set; }
    public DateTime? CompletedUtc { get; set; }
}
