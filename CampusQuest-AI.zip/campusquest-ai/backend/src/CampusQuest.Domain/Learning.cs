namespace CampusQuest.Domain;

public class Course : Entity
{
    public string Title { get; set; } = "";
    public string Slug { get; set; } = "";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "";
    public Difficulty Difficulty { get; set; }
    public int EstimatedMinutes { get; set; }
    public bool IsPublished { get; set; }
    public List<Module> Modules { get; set; } = new();
}

public class Module : Entity
{
    public Guid CourseId { get; set; }
    public Course Course { get; set; } = null!;
    public string Title { get; set; } = "";
    public int Order { get; set; }
    public List<Lesson> Lessons { get; set; } = new();
}

public class Lesson : Entity
{
    public Guid ModuleId { get; set; }
    public Module Module { get; set; } = null!;
    public string Title { get; set; } = "";
    public string Content { get; set; } = "";
    public int Order { get; set; }
    public int EstimatedMinutes { get; set; }
}

public class Enrollment : Entity
{
    public Guid UserId { get; set; }
    public Guid CourseId { get; set; }
    public Course Course { get; set; } = null!;
    public DateTime EnrolledUtc { get; set; }
    public DateTime? CompletedUtc { get; set; }
}

public class LessonProgress : Entity
{
    public Guid UserId { get; set; }
    public Guid LessonId { get; set; }
    public Lesson Lesson { get; set; } = null!;
    public DateTime CompletedUtc { get; set; }
}

public class Quiz : Entity
{
    public Guid? CourseId { get; set; }
    public Course? Course { get; set; }
    public Guid? LessonId { get; set; }
    public Lesson? Lesson { get; set; }
    public string Title { get; set; } = "";
    public int PassPercent { get; set; } = 70;
    public int? TimeLimitSeconds { get; set; }
    public List<Question> Questions { get; set; } = new();
}

public class Question : Entity
{
    public Guid QuizId { get; set; }
    public Quiz Quiz { get; set; } = null!;
    public string Text { get; set; } = "";
    public string Explanation { get; set; } = "";
    public int Order { get; set; }
    public List<AnswerOption> Options { get; set; } = new();
}

public class AnswerOption : Entity
{
    public Guid QuestionId { get; set; }
    public Question Question { get; set; } = null!;
    public string Text { get; set; } = "";
    public bool IsCorrect { get; set; }
}

public class QuizAttempt : Entity
{
    public Guid UserId { get; set; }
    public Guid QuizId { get; set; }
    public Quiz Quiz { get; set; } = null!;
    public decimal ScorePercent { get; set; }
    public bool Passed { get; set; }
    public DateTime StartedUtc { get; set; }
    public DateTime SubmittedUtc { get; set; }
    public List<AttemptAnswer> Answers { get; set; } = new();
}

public class AttemptAnswer : Entity
{
    public Guid QuizAttemptId { get; set; }
    public QuizAttempt QuizAttempt { get; set; } = null!;
    public Guid QuestionId { get; set; }
    public Question Question { get; set; } = null!;
    public Guid? SelectedOptionId { get; set; }
    public AnswerOption? SelectedOption { get; set; }
    public bool IsCorrect { get; set; }
}
