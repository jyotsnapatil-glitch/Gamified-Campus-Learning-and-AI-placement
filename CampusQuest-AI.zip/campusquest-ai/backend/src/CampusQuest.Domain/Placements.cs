namespace CampusQuest.Domain;

public class PlacementDrive : Entity
{
    public string Title { get; set; } = "";
    public DateTime Date { get; set; }
    public string Description { get; set; } = "";
}

public class Job : Entity
{
    public Guid RecruiterUserId { get; set; }
    public Guid? PlacementDriveId { get; set; }
    public PlacementDrive? PlacementDrive { get; set; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Location { get; set; } = "";
    public decimal? MinCgpa { get; set; }
    public int? GraduationBatch { get; set; }
    public DateTime Deadline { get; set; }
    public JobStatus Status { get; set; } = JobStatus.Draft;
    public byte[] RowVersion { get; set; } = Array.Empty<byte>();
    public List<JobSkill> Skills { get; set; } = new();
}

public class JobSkill : Entity
{
    public Guid JobId { get; set; }
    public Job Job { get; set; } = null!;
    public Guid SkillId { get; set; }
    public Skill Skill { get; set; } = null!;
    public bool IsRequired { get; set; } = true;
}

public class SavedJob : Entity
{
    public Guid UserId { get; set; }
    public Guid JobId { get; set; }
    public Job Job { get; set; } = null!;
}

public class JobApplication : Entity
{
    public Guid JobId { get; set; }
    public Job Job { get; set; } = null!;
    public Guid StudentUserId { get; set; }
    public Guid? ResumeId { get; set; }
    public Resume? Resume { get; set; }
    public ApplicationStatus Status { get; set; } = ApplicationStatus.Applied;
    public byte[] RowVersion { get; set; } = Array.Empty<byte>();
    public List<ApplicationStatusHistory> History { get; set; } = new();
}

public class ApplicationStatusHistory : Entity
{
    public Guid JobApplicationId { get; set; }
    public JobApplication JobApplication { get; set; } = null!;
    public ApplicationStatus? FromStatus { get; set; }
    public ApplicationStatus ToStatus { get; set; }
    public Guid ChangedByUserId { get; set; }
    public DateTime ChangedUtc { get; set; }
    public string? Note { get; set; }
}

public class Interview : Entity
{
    public Guid JobApplicationId { get; set; }
    public JobApplication JobApplication { get; set; } = null!;
    public DateTime ScheduledUtc { get; set; }
    public InterviewMode Mode { get; set; }
    public string? LocationOrLink { get; set; }
}
