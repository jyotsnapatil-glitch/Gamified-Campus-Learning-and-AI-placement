namespace CampusQuest.Domain;

public class Notification : Entity
{
    public Guid UserId { get; set; }
    public string Type { get; set; } = "";
    public string Title { get; set; } = "";
    public string? LinkUrl { get; set; }
    public DateTime? ReadUtc { get; set; }
}

/// <summary>Never put passwords, tokens or resume contents in DetailsJson.</summary>
public class AuditLog : Entity
{
    public Guid? ActorUserId { get; set; }
    public string Action { get; set; } = "";
    public string EntityType { get; set; } = "";
    public string? EntityId { get; set; }
    public string? DetailsJson { get; set; }
}
