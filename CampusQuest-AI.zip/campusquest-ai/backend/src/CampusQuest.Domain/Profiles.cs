namespace CampusQuest.Domain;

public class StudentProfile : Entity
{
    public Guid UserId { get; set; }
    public string? College { get; set; }
    public string? Branch { get; set; }
    public int? GraduationYear { get; set; }
    public decimal? Cgpa { get; set; }
    /// <summary>IANA time zone used to decide what "a day" means for streaks.</summary>
    public string TimeZoneId { get; set; } = "Asia/Kolkata";
    public string? TargetRole { get; set; }
}

public class RecruiterProfile : Entity
{
    public Guid UserId { get; set; }
    public string Company { get; set; } = "";
    public ApprovalStatus ApprovalStatus { get; set; } = ApprovalStatus.Pending;
    public Guid? ApprovedByUserId { get; set; }
    public DateTime? DecidedUtc { get; set; }
}

public class RefreshToken : Entity
{
    public Guid UserId { get; set; }
    /// <summary>SHA-256 of the token. The raw token is never stored.</summary>
    public string TokenHash { get; set; } = "";
    public DateTime ExpiresUtc { get; set; }
    public DateTime? RevokedUtc { get; set; }
    public string? ReplacedByHash { get; set; }
}
