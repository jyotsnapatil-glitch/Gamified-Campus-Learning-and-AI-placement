namespace CampusQuest.Domain;

public class Skill : Entity
{
    public string Name { get; set; } = "";
    public string Category { get; set; } = "";
}

public class StudentSkill : Entity
{
    public Guid UserId { get; set; }
    public Guid SkillId { get; set; }
    public Skill Skill { get; set; } = null!;
    public SkillLevel Level { get; set; }
    public List<SkillEvidence> Evidence { get; set; } = new();
}

/// <summary>Why we believe a student has a skill. Self-declared and quiz-assessed are never "certified".</summary>
public class SkillEvidence : Entity
{
    public Guid StudentSkillId { get; set; }
    public StudentSkill StudentSkill { get; set; } = null!;
    public EvidenceType Type { get; set; }
    public Guid? SourceId { get; set; }
    public string? Note { get; set; }
}
