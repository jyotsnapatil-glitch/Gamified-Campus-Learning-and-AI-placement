using System.Text.Json;
using CampusQuest.Application.Auth;
using CampusQuest.Application.Common;
using CampusQuest.Domain;
using CampusQuest.Infrastructure.Identity;
using CampusQuest.Infrastructure.Persistence;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CampusQuest.Infrastructure.Auth;

public class AuthService : IAuthService
{
    private const string InvalidCredentials = "Invalid email or password.";

    private readonly UserManager<ApplicationUser> _users;
    private readonly AppDbContext _db;
    private readonly ITokenService _tokens;
    private readonly TimeProvider _time;

    public AuthService(UserManager<ApplicationUser> users, AppDbContext db, ITokenService tokens, TimeProvider time)
    {
        _users = users;
        _db = db;
        _tokens = tokens;
        _time = time;
    }

    private DateTime Now => _time.GetUtcNow().UtcDateTime;

    public async Task<ServiceResult<RegisterResponse>> RegisterAsync(RegisterRequest request, CancellationToken ct = default)
    {
        var errors = RegisterValidator.Validate(request);
        if (errors.Count > 0) return ServiceResult<RegisterResponse>.Invalid(errors);

        var role = RegisterValidator.NormalizeRole(request.Role)!; // validated above, never Admin
        var email = request.Email.Trim();

        if (await _users.FindByEmailAsync(email) is not null)
            return ServiceResult<RegisterResponse>.Fail(ErrorKind.Conflict, "An account with this email already exists.");

        var user = new ApplicationUser
        {
            Id = Guid.NewGuid(),
            UserName = email,
            Email = email,
            FullName = request.FullName.Trim(),
            CreatedUtc = Now,
        };

        var created = await _users.CreateAsync(user, request.Password);
        if (!created.Succeeded)
        {
            if (created.Errors.Any(e => e.Code is "DuplicateEmail" or "DuplicateUserName"))
                return ServiceResult<RegisterResponse>.Fail(ErrorKind.Conflict, "An account with this email already exists.");
            return ServiceResult<RegisterResponse>.Invalid(new Dictionary<string, string[]>
            {
                ["password"] = created.Errors.Select(e => e.Description).ToArray(),
            });
        }

        try
        {
            await _users.AddToRoleAsync(user, role);
            if (role == AppRoles.Recruiter)
                _db.RecruiterProfiles.Add(new RecruiterProfile { UserId = user.Id, Company = request.Company!.Trim() });
            else
                _db.StudentProfiles.Add(new StudentProfile { UserId = user.Id });
            Audit(user.Id, "auth.register", nameof(ApplicationUser), user.Id.ToString(), new { role });
            await _db.SaveChangesAsync(ct);
        }
        catch
        {
            await _users.DeleteAsync(user); // do not leave a half-created account behind
            throw;
        }

        var needsApproval = role == AppRoles.Recruiter;
        return ServiceResult<RegisterResponse>.Ok(new RegisterResponse(
            needsApproval
                ? "Account created. A recruiter account must be approved by an administrator before you can sign in."
                : "Account created. You can sign in now.",
            needsApproval));
    }

    public async Task<ServiceResult<LoginResult>> LoginAsync(LoginRequest request, CancellationToken ct = default)
    {
        var user = await _users.FindByEmailAsync((request.Email ?? "").Trim());
        if (user is null)
            return ServiceResult<LoginResult>.Fail(ErrorKind.Unauthorized, InvalidCredentials);

        if (await _users.IsLockedOutAsync(user))
            return ServiceResult<LoginResult>.Fail(ErrorKind.TooManyRequests, "Too many failed attempts. Try again in a few minutes.");

        if (!await _users.CheckPasswordAsync(user, request.Password ?? ""))
        {
            await _users.AccessFailedAsync(user); // counts toward lockout
            Audit(user.Id, "auth.login_failed", nameof(ApplicationUser), user.Id.ToString(), null);
            await _db.SaveChangesAsync(ct);
            return ServiceResult<LoginResult>.Fail(ErrorKind.Unauthorized, InvalidCredentials);
        }

        await _users.ResetAccessFailedCountAsync(user);

        var gate = await CheckCanSignInAsync(user, ct);
        if (gate is not null) return gate;

        var role = (await _users.GetRolesAsync(user)).First();
        var result = IssueTokens(user, role);
        Audit(user.Id, "auth.login", nameof(ApplicationUser), user.Id.ToString(), null);
        await _db.SaveChangesAsync(ct);
        return ServiceResult<LoginResult>.Ok(result);
    }

    public async Task<ServiceResult<LoginResult>> RefreshAsync(string? refreshToken, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(refreshToken))
            return ServiceResult<LoginResult>.Fail(ErrorKind.Unauthorized, "Session expired. Please sign in again.");

        var hash = _tokens.HashRefreshToken(refreshToken);
        var stored = await _db.RefreshTokens.FirstOrDefaultAsync(t => t.TokenHash == hash, ct);
        if (stored is null)
            return ServiceResult<LoginResult>.Fail(ErrorKind.Unauthorized, "Session expired. Please sign in again.");

        if (stored.RevokedUtc is not null)
        {
            // A rotated token was presented again: assume theft and end every session for this user.
            await RevokeAllAsync(stored.UserId, ct);
            Audit(stored.UserId, "auth.refresh_reuse_detected", nameof(RefreshToken), stored.Id.ToString(), null);
            await _db.SaveChangesAsync(ct);
            return ServiceResult<LoginResult>.Fail(ErrorKind.Unauthorized, "Session expired. Please sign in again.");
        }

        if (stored.ExpiresUtc <= Now)
            return ServiceResult<LoginResult>.Fail(ErrorKind.Unauthorized, "Session expired. Please sign in again.");

        var user = await _users.FindByIdAsync(stored.UserId.ToString());
        if (user is null)
            return ServiceResult<LoginResult>.Fail(ErrorKind.Unauthorized, "Session expired. Please sign in again.");

        var gate = await CheckCanSignInAsync(user, ct);
        if (gate is not null) return gate;

        var role = (await _users.GetRolesAsync(user)).First();
        var result = IssueTokens(user, role, replacing: stored);
        await _db.SaveChangesAsync(ct);
        return ServiceResult<LoginResult>.Ok(result);
    }

    public async Task LogoutAsync(string? refreshToken, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(refreshToken)) return;
        var hash = _tokens.HashRefreshToken(refreshToken);
        var stored = await _db.RefreshTokens.FirstOrDefaultAsync(t => t.TokenHash == hash, ct);
        if (stored is null || stored.RevokedUtc is not null) return;
        stored.RevokedUtc = Now;
        await _db.SaveChangesAsync(ct);
    }

    public async Task<ServiceResult<UserDto>> GetCurrentUserAsync(Guid userId, CancellationToken ct = default)
    {
        var user = await _users.FindByIdAsync(userId.ToString());
        if (user is null) return ServiceResult<UserDto>.Fail(ErrorKind.NotFound, "User not found.");
        var role = (await _users.GetRolesAsync(user)).FirstOrDefault() ?? "";
        return ServiceResult<UserDto>.Ok(new UserDto(user.Id, user.FullName, user.Email!, role));
    }

    private async Task<ServiceResult<LoginResult>?> CheckCanSignInAsync(ApplicationUser user, CancellationToken ct)
    {
        if (!user.IsActive)
            return ServiceResult<LoginResult>.Fail(ErrorKind.Forbidden, "This account has been deactivated.");

        if (await _users.IsInRoleAsync(user, AppRoles.Recruiter))
        {
            var profile = await _db.RecruiterProfiles.AsNoTracking().FirstOrDefaultAsync(p => p.UserId == user.Id, ct);
            if (profile is null || profile.ApprovalStatus != ApprovalStatus.Approved)
                return ServiceResult<LoginResult>.Fail(ErrorKind.Forbidden,
                    profile?.ApprovalStatus == ApprovalStatus.Rejected
                        ? "Your recruiter account was not approved."
                        : "Your recruiter account is awaiting administrator approval.");
        }
        return null;
    }

    private LoginResult IssueTokens(ApplicationUser user, string role, RefreshToken? replacing = null)
    {
        var access = _tokens.CreateAccessToken(user.Id, user.Email!, user.FullName, role);

        var raw = _tokens.GenerateRefreshToken();
        var hash = _tokens.HashRefreshToken(raw);
        var expires = Now.Add(_tokens.RefreshTokenLifetime);
        _db.RefreshTokens.Add(new RefreshToken { UserId = user.Id, TokenHash = hash, ExpiresUtc = expires });

        if (replacing is not null)
        {
            replacing.RevokedUtc = Now;
            replacing.ReplacedByHash = hash;
        }

        var response = new AuthResponse(
            access.Value,
            (int)(access.ExpiresUtc - Now).TotalSeconds,
            new UserDto(user.Id, user.FullName, user.Email!, role));
        return new LoginResult(response, raw, expires);
    }

    private async Task RevokeAllAsync(Guid userId, CancellationToken ct)
    {
        var active = await _db.RefreshTokens.Where(t => t.UserId == userId && t.RevokedUtc == null).ToListAsync(ct);
        foreach (var t in active) t.RevokedUtc = Now;
    }

    private void Audit(Guid? actor, string action, string entityType, string? entityId, object? details) =>
        _db.AuditLogs.Add(new AuditLog
        {
            ActorUserId = actor,
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            DetailsJson = details is null ? null : JsonSerializer.Serialize(details), // never log passwords or tokens
        });
}
