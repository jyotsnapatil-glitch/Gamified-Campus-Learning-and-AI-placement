namespace CampusQuest.Infrastructure.Auth;

public class JwtOptions
{
    public const string Section = "Jwt";

    /// <summary>Signing key (at least 32 characters). Use user-secrets locally and Key Vault in Azure.</summary>
    public string Key { get; set; } = "";
    public string Issuer { get; set; } = "CampusQuest";
    public string Audience { get; set; } = "CampusQuestWeb";
    public int AccessTokenMinutes { get; set; } = 15;
    public int RefreshTokenDays { get; set; } = 14;
}
