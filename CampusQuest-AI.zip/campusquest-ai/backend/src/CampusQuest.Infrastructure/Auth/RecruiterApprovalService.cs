using System.Text.Json;
using CampusQuest.Application.Auth;
using CampusQuest.Application.Common;
using CampusQuest.Domain;
using CampusQuest.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace CampusQuest.Infrastructure.Auth;

public class RecruiterApprovalService : IRecruiterApprovalService
{
    private readonly AppDbContext _db;
    private readonly TimeProvider _time;

    public RecruiterApprovalService(AppDbContext db, TimeProvider time)
    {
        _db = db;
        _time = time;
    }

    public async Task<IReadOnlyList<RecruiterDto>> ListAsync(ApprovalStatus status, CancellationToken ct = default)
    {
        var rows = await (
            from p in _db.RecruiterProfiles.AsNoTracking()
            join u in _db.Users.AsNoTracking() on p.UserId equals u.Id
            where p.ApprovalStatus == status
            orderby p.CreatedUtc
            select new { p.UserId, u.FullName, u.Email, p.Company, p.ApprovalStatus, p.CreatedUtc, p.DecidedUtc }
        ).ToListAsync(ct);

        return rows.Select(r => new RecruiterDto(r.UserId, r.FullName, r.Email ?? "", r.Company, r.ApprovalStatus.ToString(), r.CreatedUtc, r.DecidedUtc)).ToList();
    }

    public async Task<ServiceResult<RecruiterDto>> DecideAsync(Guid recruiterUserId, bool approve, Guid adminUserId, CancellationToken ct = default)
    {
        var profile = await _db.RecruiterProfiles.FirstOrDefaultAsync(p => p.UserId == recruiterUserId, ct);
        if (profile is null) return ServiceResult<RecruiterDto>.Fail(ErrorKind.NotFound, "Recruiter not found.");

        var target = approve ? ApprovalStatus.Approved : ApprovalStatus.Rejected;
        if (profile.ApprovalStatus != target)
        {
            profile.ApprovalStatus = target;
            profile.ApprovedByUserId = adminUserId;
            profile.DecidedUtc = _time.GetUtcNow().UtcDateTime;

            _db.Notifications.Add(new Notification
            {
                UserId = recruiterUserId,
                Type = "recruiter.decision",
                Title = approve ? "Your recruiter account was approved. You can now post jobs." : "Your recruiter account was not approved.",
            });
            _db.AuditLogs.Add(new AuditLog
            {
                ActorUserId = adminUserId,
                Action = approve ? "admin.recruiter_approved" : "admin.recruiter_rejected",
                EntityType = nameof(RecruiterProfile),
                EntityId = profile.Id.ToString(),
                DetailsJson = JsonSerializer.Serialize(new { recruiterUserId }),
            });
            await _db.SaveChangesAsync(ct);
        }

        var user = await _db.Users.AsNoTracking().FirstAsync(u => u.Id == recruiterUserId, ct);
        return ServiceResult<RecruiterDto>.Ok(new RecruiterDto(
            recruiterUserId, user.FullName, user.Email ?? "", profile.Company,
            profile.ApprovalStatus.ToString(), profile.CreatedUtc, profile.DecidedUtc));
    }
}
