using CampusQuest.Domain;
using CampusQuest.Infrastructure.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CampusQuest.Infrastructure.Persistence;

public class AppDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, Guid>
{
    private readonly TimeProvider _time;

    public AppDbContext(DbContextOptions<AppDbContext> options, TimeProvider time) : base(options)
    {
        _time = time;
    }

    public DbSet<StudentProfile> StudentProfiles => Set<StudentProfile>();
    public DbSet<RecruiterProfile> RecruiterProfiles => Set<RecruiterProfile>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();

    public DbSet<Course> Courses => Set<Course>();
    public DbSet<Module> Modules => Set<Module>();
    public DbSet<Lesson> Lessons => Set<Lesson>();
    public DbSet<Enrollment> Enrollments => Set<Enrollment>();
    public DbSet<LessonProgress> LessonProgressRecords => Set<LessonProgress>();
    public DbSet<Quiz> Quizzes => Set<Quiz>();
    public DbSet<Question> Questions => Set<Question>();
    public DbSet<AnswerOption> AnswerOptions => Set<AnswerOption>();
    public DbSet<QuizAttempt> QuizAttempts => Set<QuizAttempt>();
    public DbSet<AttemptAnswer> AttemptAnswers => Set<AttemptAnswer>();

    public DbSet<Skill> Skills => Set<Skill>();
    public DbSet<StudentSkill> StudentSkills => Set<StudentSkill>();
    public DbSet<SkillEvidence> SkillEvidenceRecords => Set<SkillEvidence>();

    public DbSet<XpTransaction> XpTransactions => Set<XpTransaction>();
    public DbSet<Badge> Badges => Set<Badge>();
    public DbSet<StudentBadge> StudentBadges => Set<StudentBadge>();
    public DbSet<Mission> Missions => Set<Mission>();
    public DbSet<MissionProgress> MissionProgressRecords => Set<MissionProgress>();

    public DbSet<Resume> Resumes => Set<Resume>();
    public DbSet<ResumeAnalysis> ResumeAnalyses => Set<ResumeAnalysis>();
    public DbSet<Roadmap> Roadmaps => Set<Roadmap>();
    public DbSet<RoadmapStep> RoadmapSteps => Set<RoadmapStep>();

    public DbSet<PlacementDrive> PlacementDrives => Set<PlacementDrive>();
    public DbSet<Job> Jobs => Set<Job>();
    public DbSet<JobSkill> JobSkills => Set<JobSkill>();
    public DbSet<SavedJob> SavedJobs => Set<SavedJob>();
    public DbSet<JobApplication> JobApplications => Set<JobApplication>();
    public DbSet<ApplicationStatusHistory> ApplicationStatusHistories => Set<ApplicationStatusHistory>();
    public DbSet<Interview> Interviews => Set<Interview>();

    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
    {
        // Indexed strings need a bounded length in SQL Server. Long text columns opt out below.
        configurationBuilder.Properties<string>().HaveMaxLength(256);
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // Identity
        b.Entity<ApplicationUser>(e => e.Property(u => u.FullName).HasMaxLength(200));

        // Profiles
        b.Entity<StudentProfile>(e =>
        {
            e.HasIndex(x => x.UserId).IsUnique();
            e.Property(x => x.Cgpa).HasPrecision(4, 2);
        });
        b.Entity<RecruiterProfile>(e => e.HasIndex(x => x.UserId).IsUnique());
        b.Entity<RefreshToken>(e =>
        {
            e.Property(x => x.TokenHash).HasMaxLength(128);
            e.Property(x => x.ReplacedByHash).HasMaxLength(128);
            e.HasIndex(x => x.TokenHash).IsUnique();
            e.HasIndex(x => x.UserId);
        });

        // Learning
        b.Entity<Course>(e =>
        {
            e.Property(x => x.Slug).HasMaxLength(100);
            e.HasIndex(x => x.Slug).IsUnique();
            e.Property(x => x.Description).HasMaxLength(int.MaxValue);
        });
        b.Entity<Lesson>(e => e.Property(x => x.Content).HasMaxLength(int.MaxValue));
        b.Entity<Enrollment>(e => e.HasIndex(x => new { x.UserId, x.CourseId }).IsUnique());
        b.Entity<LessonProgress>(e => e.HasIndex(x => new { x.UserId, x.LessonId }).IsUnique());
        b.Entity<Question>(e =>
        {
            e.Property(x => x.Text).HasMaxLength(2000);
            e.Property(x => x.Explanation).HasMaxLength(2000);
        });
        b.Entity<QuizAttempt>(e =>
        {
            e.Property(x => x.ScorePercent).HasPrecision(5, 2);
            e.HasIndex(x => new { x.UserId, x.QuizId });
        });

        // Skills
        b.Entity<Skill>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(100);
            e.HasIndex(x => x.Name).IsUnique();
        });
        b.Entity<StudentSkill>(e => e.HasIndex(x => new { x.UserId, x.SkillId }).IsUnique());

        // Gamification
        b.Entity<XpTransaction>(e =>
        {
            e.Property(x => x.SourceType).HasMaxLength(50);
            e.HasIndex(x => new { x.UserId, x.SourceType, x.SourceId }).IsUnique(); // idempotent awards
            e.HasIndex(x => new { x.UserId, x.CreatedUtc });                       // weekly leaderboards
        });
        b.Entity<Badge>(e =>
        {
            e.Property(x => x.Code).HasMaxLength(50);
            e.HasIndex(x => x.Code).IsUnique();
        });
        b.Entity<StudentBadge>(e => e.HasIndex(x => new { x.UserId, x.BadgeId }).IsUnique());
        b.Entity<Mission>(e =>
        {
            e.Property(x => x.Code).HasMaxLength(50);
            e.HasIndex(x => x.Code).IsUnique();
        });
        b.Entity<MissionProgress>(e => e.HasIndex(x => new { x.UserId, x.MissionId, x.PeriodStartUtc }).IsUnique());

        // AI features
        b.Entity<Resume>(e => e.Property(x => x.ContentHash).HasMaxLength(128));
        b.Entity<ResumeAnalysis>(e => e.Property(x => x.ResultJson).HasMaxLength(int.MaxValue));
        b.Entity<RoadmapStep>(e => e.Property(x => x.Reason).HasMaxLength(2000));

        // Placements
        b.Entity<Job>(e =>
        {
            e.Property(x => x.Description).HasMaxLength(int.MaxValue);
            e.Property(x => x.MinCgpa).HasPrecision(4, 2);
            e.Property(x => x.RowVersion).IsRowVersion();
            e.HasIndex(x => new { x.Status, x.Deadline });
        });
        b.Entity<JobSkill>(e => e.HasIndex(x => new { x.JobId, x.SkillId }).IsUnique());
        b.Entity<SavedJob>(e => e.HasIndex(x => new { x.UserId, x.JobId }).IsUnique());
        b.Entity<JobApplication>(e =>
        {
            e.Property(x => x.RowVersion).IsRowVersion();
            e.HasIndex(x => new { x.JobId, x.StudentUserId }).IsUnique(); // one application per job
            e.HasIndex(x => new { x.JobId, x.Status });
        });

        // Platform
        b.Entity<Notification>(e =>
        {
            e.Property(x => x.LinkUrl).HasMaxLength(500);
            e.HasIndex(x => new { x.UserId, x.ReadUtc });
        });
        b.Entity<AuditLog>(e =>
        {
            e.Property(x => x.DetailsJson).HasMaxLength(int.MaxValue);
            e.HasIndex(x => x.CreatedUtc);
        });

        LinkUserForeignKeys(b);
        RestrictDeletes(b);
    }

    private static bool IsDomainType(Type t) => t.Namespace?.StartsWith("CampusQuest.Domain", StringComparison.Ordinal) == true;

    /// <summary>Any Guid property ending in "UserId" on a domain entity becomes a foreign key to AspNetUsers.</summary>
    private static void LinkUserForeignKeys(ModelBuilder b)
    {
        foreach (var entityType in b.Model.GetEntityTypes().Where(t => IsDomainType(t.ClrType)).ToList())
        {
            var userIdProps = entityType.ClrType.GetProperties()
                .Where(p => p.Name.EndsWith("UserId", StringComparison.Ordinal)
                            && (p.PropertyType == typeof(Guid) || p.PropertyType == typeof(Guid?)));
            foreach (var prop in userIdProps)
            {
                b.Entity(entityType.ClrType)
                    .HasOne(typeof(ApplicationUser))
                    .WithMany()
                    .HasForeignKey(prop.Name)
                    .OnDelete(DeleteBehavior.Restrict);
            }
        }
    }

    /// <summary>SQL Server rejects multiple cascade paths, and silent cascades are risky. Deletes must be explicit.</summary>
    private static void RestrictDeletes(ModelBuilder b)
    {
        foreach (var fk in b.Model.GetEntityTypes()
                     .Where(t => IsDomainType(t.ClrType))
                     .SelectMany(t => t.GetForeignKeys()))
        {
            fk.DeleteBehavior = DeleteBehavior.Restrict;
        }
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var now = _time.GetUtcNow().UtcDateTime;
        foreach (var entry in ChangeTracker.Entries<Entity>())
        {
            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedUtc = now;
                entry.Entity.UpdatedUtc = now;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.UpdatedUtc = now;
            }
        }
        return base.SaveChangesAsync(cancellationToken);
    }
}
