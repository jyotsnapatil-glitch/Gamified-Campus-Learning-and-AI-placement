using CampusQuest.Domain;
using CampusQuest.Infrastructure.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace CampusQuest.Infrastructure.Persistence;

/// <summary>
/// Idempotent seeding. Reference data uses fixed IDs so every environment gets the same rows, and nothing that
/// already exists is overwritten. Demo accounts are created ONLY in Development and ONLY when
/// Seed:DemoPassword is configured (user-secrets), so there are no hard-coded credentials.
/// </summary>
public static class DbSeeder
{
    public const string DemoStudentEmail = "student@campusquest.local";
    public const string DemoRecruiterEmail = "recruiter@campusquest.local";
    public const string DemoAdminEmail = "admin@campusquest.local";

    public static async Task SeedAsync(IServiceProvider services, bool allowDemoAccounts, CancellationToken ct = default)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;
        var db = sp.GetRequiredService<AppDbContext>();
        var log = sp.GetRequiredService<ILoggerFactory>().CreateLogger("DbSeeder");

        await SeedRolesAsync(sp.GetRequiredService<RoleManager<ApplicationRole>>());
        await SeedReferenceDataAsync(db, ct);

        if (!allowDemoAccounts) return;

        var config = sp.GetRequiredService<IConfiguration>();
        var password = config["Seed:DemoPassword"];
        if (string.IsNullOrWhiteSpace(password))
        {
            log.LogWarning("Seed:DemoPassword is not set, so demo accounts were not created. See the README.");
            return;
        }
        await SeedDemoAccountsAsync(sp.GetRequiredService<UserManager<ApplicationUser>>(), db, password, ct);
    }

    private static async Task SeedRolesAsync(RoleManager<ApplicationRole> roles)
    {
        foreach (var name in AppRoles.All)
            if (!await roles.RoleExistsAsync(name))
                await roles.CreateAsync(new ApplicationRole(name) { Id = StableGuid("role:" + name) });
    }

    private static async Task SeedReferenceDataAsync(AppDbContext db, CancellationToken ct)
    {
        var skillNames = new[]
        {
            ("C#", "Programming"), ("Java", "Programming"), ("Python", "Programming"), ("JavaScript", "Programming"),
            ("TypeScript", "Programming"), ("SQL", "Databases"), ("ASP.NET Core", "Backend"), ("REST APIs", "Backend"),
            ("Angular", "Frontend"), ("React", "Frontend"), ("Data Structures", "Computer Science"),
            ("Algorithms", "Computer Science"), ("OOP", "Computer Science"), ("Operating Systems", "Computer Science"),
            ("Computer Networks", "Computer Science"), ("Git", "Tools"),
        };
        var existingSkills = (await db.Skills.Select(s => s.Name).ToListAsync(ct)).ToHashSet();
        foreach (var (name, category) in skillNames.Where(s => !existingSkills.Contains(s.Item1)))
            db.Skills.Add(new Skill { Id = StableGuid("skill:" + name), Name = name, Category = category });

        var badges = new[]
        {
            ("FIRST_STEPS", "First steps", "Completed your first assessment."),
            ("PERFECT_SCORE", "Perfect score", "Scored 100% on an assessment."),
            ("RISING_STAR", "Rising star", "Reached 100 XP."),
            ("STREAK_7", "7-day streak", "Learned seven days in a row."),
            ("PATH_COMPLETE", "Path complete", "Completed a learning path."),
        };
        var existingBadges = (await db.Badges.Select(b => b.Code).ToListAsync(ct)).ToHashSet();
        foreach (var (code, name, description) in badges.Where(b => !existingBadges.Contains(b.Item1)))
            db.Badges.Add(new Badge { Id = StableGuid("badge:" + code), Code = code, Name = name, Description = description });

        var missions = new[]
        {
            ("DAILY_LESSON", "Complete one lesson", MissionPeriod.Daily, 1, 20),
            ("DAILY_QUIZ", "Pass one quiz", MissionPeriod.Daily, 1, 50),
            ("WEEKLY_LESSONS", "Complete five lessons this week", MissionPeriod.Weekly, 5, 100),
        };
        var existingMissions = (await db.Missions.Select(m => m.Code).ToListAsync(ct)).ToHashSet();
        foreach (var (code, title, period, target, xp) in missions.Where(m => !existingMissions.Contains(m.Item1)))
            db.Missions.Add(new Mission { Id = StableGuid("mission:" + code), Code = code, Title = title, Period = period, TargetCount = target, XpReward = xp });

        await db.SaveChangesAsync(ct);
    }

    private static async Task SeedDemoAccountsAsync(UserManager<ApplicationUser> users, AppDbContext db, string password, CancellationToken ct)
    {
        await CreateDemoUserAsync(users, db, DemoAdminEmail, "Demo Admin", AppRoles.Admin, password, ct);
        await CreateDemoUserAsync(users, db, DemoRecruiterEmail, "Demo Recruiter", AppRoles.Recruiter, password, ct);
        await CreateDemoUserAsync(users, db, DemoStudentEmail, "Demo Student", AppRoles.Student, password, ct);
    }

    private static async Task CreateDemoUserAsync(UserManager<ApplicationUser> users, AppDbContext db, string email, string name, string role, string password, CancellationToken ct)
    {
        if (await users.FindByEmailAsync(email) is not null) return;

        var user = new ApplicationUser
        {
            Id = StableGuid("user:" + email),
            UserName = email,
            Email = email,
            EmailConfirmed = true,
            FullName = name,
            CreatedUtc = DateTime.UtcNow,
        };
        var created = await users.CreateAsync(user, password);
        if (!created.Succeeded)
            throw new InvalidOperationException("Could not create demo user: " + string.Join("; ", created.Errors.Select(e => e.Description)));
        await users.AddToRoleAsync(user, role);

        if (role == AppRoles.Student) db.StudentProfiles.Add(new StudentProfile { UserId = user.Id });
        if (role == AppRoles.Recruiter)
            db.RecruiterProfiles.Add(new RecruiterProfile { UserId = user.Id, Company = "Demo Company", ApprovalStatus = ApprovalStatus.Approved, DecidedUtc = DateTime.UtcNow });
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Deterministic GUID from a string, so seeded rows have the same ID in every environment.</summary>
    public static Guid StableGuid(string key)
    {
        var hash = System.Security.Cryptography.MD5.HashData(System.Text.Encoding.UTF8.GetBytes("campusquest:" + key));
        return new Guid(hash);
    }
}
