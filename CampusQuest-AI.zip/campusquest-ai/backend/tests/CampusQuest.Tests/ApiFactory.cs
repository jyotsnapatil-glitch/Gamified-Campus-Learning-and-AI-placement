using CampusQuest.Infrastructure.Persistence;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace CampusQuest.Tests;

/// <summary>Runs the real API in memory with an in-memory database. No SQL Server needed.</summary>
public class ApiFactory : WebApplicationFactory<Program>
{
    public const string DemoPassword = "Test-Passw0rd1";

    private readonly string _dbName = "campusquest-tests-" + Guid.NewGuid();
    private readonly object _lock = new();
    private bool _seeded;

    static ApiFactory()
    {
        // Environment variables are read by WebApplication.CreateBuilder, so Program sees them while registering services.
        Environment.SetEnvironmentVariable("Jwt__Key", "integration-test-key-integration-test-key-0123");
        Environment.SetEnvironmentVariable("Auth__CookieSecure", "false");
        Environment.SetEnvironmentVariable("Database__MigrateOnStartup", "false");
        Environment.SetEnvironmentVariable("Database__SeedOnStartup", "false");
        Environment.SetEnvironmentVariable("RateLimiting__AuthPermitPerMinute", "100000");
        Environment.SetEnvironmentVariable("ConnectionStrings__Default", "Server=unused;Database=unused");
        Environment.SetEnvironmentVariable("Seed__DemoPassword", DemoPassword);
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.ConfigureServices(services =>
        {
            services.RemoveAll<DbContextOptions<AppDbContext>>();
            services.RemoveAll<IDbContextOptionsConfiguration<AppDbContext>>();
            services.AddDbContext<AppDbContext>(o => o.UseInMemoryDatabase(_dbName));
        });
    }

    /// <summary>Creates the schema and seeds roles, reference data and demo accounts once.</summary>
    public void EnsureSeeded()
    {
        lock (_lock)
        {
            if (_seeded) return;
            using (var scope = Services.CreateScope())
                scope.ServiceProvider.GetRequiredService<AppDbContext>().Database.EnsureCreated();
            DbSeeder.SeedAsync(Services, allowDemoAccounts: true).GetAwaiter().GetResult();
            _seeded = true;
        }
    }
}
