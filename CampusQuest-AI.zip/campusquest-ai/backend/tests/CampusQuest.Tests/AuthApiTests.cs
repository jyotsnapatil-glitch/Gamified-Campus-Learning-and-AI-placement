using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using CampusQuest.Infrastructure.Persistence;

namespace CampusQuest.Tests;

public class AuthApiTests : IClassFixture<ApiFactory>
{
    private readonly ApiFactory _factory;
    private readonly HttpClient _client;

    public AuthApiTests(ApiFactory factory)
    {
        _factory = factory;
        factory.EnsureSeeded();
        _client = factory.CreateClient(new() { HandleCookies = false });
    }

    private static string UniqueEmail(string prefix) => $"{prefix}-{Guid.NewGuid():N}@example.com";

    private Task<HttpResponseMessage> Register(string email, string role = "Student", string? company = null, string password = "Passw0rd1") =>
        _client.PostAsJsonAsync("/api/auth/register", new { fullName = "Test User", email, password, role, company });

    private Task<HttpResponseMessage> Login(string email, string password) =>
        _client.PostAsJsonAsync("/api/auth/login", new { email, password });

    private static string? RefreshCookieFrom(HttpResponseMessage response)
    {
        if (!response.Headers.TryGetValues("Set-Cookie", out var values)) return null;
        var line = values.FirstOrDefault(v => v.StartsWith("cq_refresh=", StringComparison.Ordinal));
        return line?.Split(';')[0]["cq_refresh=".Length..];
    }

    private static async Task<string?> Detail(HttpResponseMessage response)
    {
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("detail").GetString();
    }

    private static async Task<string> AccessTokenFrom(HttpResponseMessage response)
    {
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        return doc.RootElement.GetProperty("accessToken").GetString()!;
    }

    private async Task<HttpResponseMessage> Send(HttpMethod method, string url, string? bearer = null, string? refreshCookie = null)
    {
        var request = new HttpRequestMessage(method, url);
        if (bearer is not null) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
        if (refreshCookie is not null) request.Headers.Add("Cookie", $"cq_refresh={refreshCookie}");
        return await _client.SendAsync(request);
    }

    [Fact]
    public async Task Student_can_register_then_login()
    {
        var email = UniqueEmail("student");
        var register = await Register(email);
        Assert.Equal(HttpStatusCode.Created, register.StatusCode);

        var login = await Login(email, "Passw0rd1");
        Assert.Equal(HttpStatusCode.OK, login.StatusCode);
        Assert.False(string.IsNullOrEmpty(await AccessTokenFrom(login)));
    }

    [Fact]
    public async Task Refresh_token_is_sent_only_as_an_http_only_strict_cookie()
    {
        var email = UniqueEmail("cookie");
        await Register(email);
        var login = await Login(email, "Passw0rd1");

        var body = await login.Content.ReadAsStringAsync();
        Assert.DoesNotContain("refresh", body, StringComparison.OrdinalIgnoreCase);

        var setCookie = login.Headers.GetValues("Set-Cookie").First(v => v.StartsWith("cq_refresh="));
        Assert.Contains("httponly", setCookie, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("samesite=strict", setCookie, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("path=/api/auth", setCookie, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Cannot_register_as_admin()
    {
        var response = await Register(UniqueEmail("sneaky"), role: "Admin");
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Duplicate_email_is_a_conflict()
    {
        var email = UniqueEmail("dupe");
        Assert.Equal(HttpStatusCode.Created, (await Register(email)).StatusCode);
        Assert.Equal(HttpStatusCode.Conflict, (await Register(email)).StatusCode);
    }

    [Fact]
    public async Task Weak_password_is_rejected()
    {
        var response = await Register(UniqueEmail("weak"), password: "short");
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Wrong_password_and_unknown_user_get_the_same_response()
    {
        var email = UniqueEmail("wrongpw");
        await Register(email);

        var wrong = await Login(email, "Not-The-Password1");
        var unknown = await Login(UniqueEmail("nobody"), "Passw0rd1");

        Assert.Equal(HttpStatusCode.Unauthorized, wrong.StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, unknown.StatusCode);
        Assert.Equal(await Detail(wrong), await Detail(unknown)); // no hint about which one failed
    }

    [Fact]
    public async Task Account_locks_after_repeated_failures()
    {
        var email = UniqueEmail("lockout");
        await Register(email);
        for (var i = 0; i < 5; i++) await Login(email, "Wrong-Passw0rd1");

        var response = await Login(email, "Passw0rd1"); // correct password, but locked
        Assert.Equal(HttpStatusCode.TooManyRequests, response.StatusCode);
    }

    [Fact]
    public async Task Me_requires_a_token_and_returns_the_role()
    {
        var email = UniqueEmail("me");
        await Register(email);
        var token = await AccessTokenFrom(await Login(email, "Passw0rd1"));

        Assert.Equal(HttpStatusCode.Unauthorized, (await Send(HttpMethod.Get, "/api/auth/me")).StatusCode);

        var me = await Send(HttpMethod.Get, "/api/auth/me", bearer: token);
        Assert.Equal(HttpStatusCode.OK, me.StatusCode);
        using var doc = JsonDocument.Parse(await me.Content.ReadAsStringAsync());
        Assert.Equal("Student", doc.RootElement.GetProperty("role").GetString());
        Assert.Equal(email, doc.RootElement.GetProperty("email").GetString());
    }

    [Fact]
    public async Task Refresh_rotates_the_cookie_and_reuse_revokes_the_whole_session()
    {
        var email = UniqueEmail("rotate");
        await Register(email);
        var cookieA = RefreshCookieFrom(await Login(email, "Passw0rd1"))!;

        var refreshed = await Send(HttpMethod.Post, "/api/auth/refresh", refreshCookie: cookieA);
        Assert.Equal(HttpStatusCode.OK, refreshed.StatusCode);
        var cookieB = RefreshCookieFrom(refreshed)!;
        Assert.NotEqual(cookieA, cookieB);

        // Presenting the already-used token again looks like theft.
        var reuse = await Send(HttpMethod.Post, "/api/auth/refresh", refreshCookie: cookieA);
        Assert.Equal(HttpStatusCode.Unauthorized, reuse.StatusCode);

        // ...and the newer token is revoked too.
        var afterReuse = await Send(HttpMethod.Post, "/api/auth/refresh", refreshCookie: cookieB);
        Assert.Equal(HttpStatusCode.Unauthorized, afterReuse.StatusCode);
    }

    [Fact]
    public async Task Logout_revokes_the_refresh_token()
    {
        var email = UniqueEmail("logout");
        await Register(email);
        var cookie = RefreshCookieFrom(await Login(email, "Passw0rd1"))!;

        Assert.Equal(HttpStatusCode.NoContent, (await Send(HttpMethod.Post, "/api/auth/logout", refreshCookie: cookie)).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, (await Send(HttpMethod.Post, "/api/auth/refresh", refreshCookie: cookie)).StatusCode);
    }

    [Fact]
    public async Task Refresh_without_a_cookie_is_unauthorized() =>
        Assert.Equal(HttpStatusCode.Unauthorized, (await Send(HttpMethod.Post, "/api/auth/refresh")).StatusCode);

    [Fact]
    public async Task Recruiter_cannot_sign_in_until_an_admin_approves()
    {
        var email = UniqueEmail("recruiter");
        var register = await Register(email, role: "Recruiter", company: "Acme Tech");
        Assert.Equal(HttpStatusCode.Created, register.StatusCode);

        var blocked = await Login(email, "Passw0rd1");
        Assert.Equal(HttpStatusCode.Forbidden, blocked.StatusCode);

        var adminToken = await AccessTokenFrom(await Login(DbSeeder.DemoAdminEmail, ApiFactory.DemoPassword));
        var pending = await Send(HttpMethod.Get, "/api/admin/recruiters", bearer: adminToken);
        using var doc = JsonDocument.Parse(await pending.Content.ReadAsStringAsync());
        var userId = doc.RootElement.EnumerateArray()
            .First(r => r.GetProperty("email").GetString() == email).GetProperty("userId").GetGuid();

        var approve = await Send(HttpMethod.Post, $"/api/admin/recruiters/{userId}/approve", bearer: adminToken);
        Assert.Equal(HttpStatusCode.OK, approve.StatusCode);

        Assert.Equal(HttpStatusCode.OK, (await Login(email, "Passw0rd1")).StatusCode);
    }

    [Fact]
    public async Task Admin_endpoints_reject_anonymous_and_non_admin_callers()
    {
        Assert.Equal(HttpStatusCode.Unauthorized, (await Send(HttpMethod.Get, "/api/admin/recruiters")).StatusCode);

        var studentToken = await AccessTokenFrom(await Login(DbSeeder.DemoStudentEmail, ApiFactory.DemoPassword));
        Assert.Equal(HttpStatusCode.Forbidden, (await Send(HttpMethod.Get, "/api/admin/recruiters", bearer: studentToken)).StatusCode);

        var recruiterToken = await AccessTokenFrom(await Login(DbSeeder.DemoRecruiterEmail, ApiFactory.DemoPassword));
        Assert.Equal(HttpStatusCode.Forbidden, (await Send(HttpMethod.Get, "/api/admin/recruiters", bearer: recruiterToken)).StatusCode);

        var adminToken = await AccessTokenFrom(await Login(DbSeeder.DemoAdminEmail, ApiFactory.DemoPassword));
        Assert.Equal(HttpStatusCode.OK, (await Send(HttpMethod.Get, "/api/admin/recruiters", bearer: adminToken)).StatusCode);
    }
}
