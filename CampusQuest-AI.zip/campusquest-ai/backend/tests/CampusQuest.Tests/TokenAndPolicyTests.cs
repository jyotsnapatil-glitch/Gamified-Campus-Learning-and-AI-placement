using CampusQuest.Application.Auth;
using CampusQuest.Domain;
using CampusQuest.Infrastructure.Auth;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace CampusQuest.Tests;

public class PasswordPolicyTests
{
    [Theory]
    [InlineData("Passw0rd1", true)]
    [InlineData("short1", false)]
    [InlineData("onlyletters", false)]
    [InlineData("12345678", false)]
    [InlineData("", false)]
    public void Enforces_length_letter_and_digit(string password, bool valid) =>
        Assert.Equal(valid, PasswordPolicy.Validate(password).Count == 0);
}

public class RegisterValidatorTests
{
    private static RegisterRequest Req(string role = "Student", string? company = null, string email = "asha@example.com") =>
        new("Asha Rao", email, "Passw0rd1", role, company);

    [Fact]
    public void Accepts_a_valid_student() => Assert.Empty(RegisterValidator.Validate(Req()));

    [Theory]
    [InlineData("Admin")]
    [InlineData("admin")]
    [InlineData("SuperUser")]
    [InlineData("")]
    public void Never_allows_self_registration_as_admin_or_unknown_roles(string role)
    {
        var errors = RegisterValidator.Validate(Req(role));
        Assert.True(errors.ContainsKey("role"));
        Assert.Null(RegisterValidator.NormalizeRole(role));
    }

    [Fact]
    public void Recruiters_must_provide_a_company() =>
        Assert.True(RegisterValidator.Validate(Req("Recruiter")).ContainsKey("company"));

    [Fact]
    public void Role_matching_is_case_insensitive() =>
        Assert.Equal(AppRoles.Recruiter, RegisterValidator.NormalizeRole(" recruiter "));

    [Theory]
    [InlineData("no-at-sign")]
    [InlineData("a@b")]
    [InlineData("two@@example.com")]
    public void Rejects_bad_emails(string email) =>
        Assert.True(RegisterValidator.Validate(Req(email: email)).ContainsKey("email"));
}

public class TokenServiceTests
{
    private static TokenService Create(out JwtOptions options)
    {
        options = new JwtOptions { Key = "unit-test-key-unit-test-key-unit-test-key", Issuer = "iss", Audience = "aud", AccessTokenMinutes = 15 };
        return new TokenService(Options.Create(options), TimeProvider.System);
    }

    [Fact]
    public async Task Access_token_carries_identity_and_role_claims_and_validates()
    {
        var svc = Create(out var opts);
        var id = Guid.NewGuid();

        var token = svc.CreateAccessToken(id, "a@b.co", "Asha Rao", AppRoles.Student);

        var result = await new JsonWebTokenHandler().ValidateTokenAsync(token.Value, new TokenValidationParameters
        {
            ValidIssuer = opts.Issuer,
            ValidAudience = opts.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(opts.Key)),
        });

        Assert.True(result.IsValid);
        Assert.Equal(id.ToString(), result.Claims["sub"]);
        Assert.Equal(AppRoles.Student, result.Claims["role"]);
        Assert.True(token.ExpiresUtc > DateTime.UtcNow.AddMinutes(14));
    }

    [Fact]
    public async Task Token_signed_with_a_different_key_is_rejected()
    {
        var svc = Create(out var opts);
        var token = svc.CreateAccessToken(Guid.NewGuid(), "a@b.co", "Asha", AppRoles.Admin);

        var result = await new JsonWebTokenHandler().ValidateTokenAsync(token.Value, new TokenValidationParameters
        {
            ValidIssuer = opts.Issuer,
            ValidAudience = opts.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("another-key-another-key-another-key-1234")),
        });

        Assert.False(result.IsValid);
    }

    [Fact]
    public void Refresh_tokens_are_random_and_hashing_is_deterministic()
    {
        var svc = Create(out _);
        var a = svc.GenerateRefreshToken();
        var b = svc.GenerateRefreshToken();

        Assert.NotEqual(a, b);
        Assert.True(a.Length >= 80);
        Assert.Equal(svc.HashRefreshToken(a), svc.HashRefreshToken(a));
        Assert.NotEqual(svc.HashRefreshToken(a), svc.HashRefreshToken(b));
        Assert.NotEqual(a, svc.HashRefreshToken(a)); // the raw token is never what gets stored
    }
}
