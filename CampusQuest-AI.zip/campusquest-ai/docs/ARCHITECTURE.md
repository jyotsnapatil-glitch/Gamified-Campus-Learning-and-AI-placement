# Architecture

## Goal
CampusQuest AI helps students learn, assess, earn XP, verify skills, get AI career guidance and apply for campus
placements. Roles: **Student**, **Recruiter** (needs admin approval) and **Admin** (never self-registered).

## Stack
| Layer | Technology |
|---|---|
| Frontend | Angular 21 (standalone components, signals), TypeScript, Tailwind CSS 4, Lucide icons |
| API | ASP.NET Core on .NET 10 LTS, Entity Framework Core |
| Database | SQL Server |
| Identity | ASP.NET Core Identity, JWT access tokens, rotating refresh tokens in an HttpOnly cookie |
| Tests | Vitest (frontend), xUnit + WebApplicationFactory (backend) |
| Planned | AI provider behind an interface with an honest demo mode, Azure App Service / Azure SQL / Blob Storage / Key Vault |

## Backend layers
```
CampusQuest.Domain          entities and enums (no dependencies)
CampusQuest.Application     DTOs, rules, service interfaces
CampusQuest.Infrastructure  EF Core, Identity, token and auth services, seeding
CampusQuest.Api             controllers, authentication, CORS, rate limiting
CampusQuest.Tests           unit and integration tests
```

## Frontend data layer
Pages inject abstract service classes (`DashboardService`, `NotificationService`, `AuthApi`). Phase 2 provides in-memory
mocks; connecting the API means providing HTTP implementations of the same classes in `app.config.ts`.

## Key design rules
- Business rules live on the server. The client never decides XP, scores, eligibility or status transitions.
- XP is an append-only ledger with a unique index on (user, source type, source id), which makes awards idempotent.
  Total XP, level and leaderboards are derived from it.
- Skills record their evidence type (self-declared, quiz-assessed, coding challenge, course completion, externally
  verified). Self-declared and quiz-assessed skills are never called certified.
- Application status follows a state machine: Applied, Under Review, Shortlisted, Interview Scheduled, Selected,
  Rejected, Withdrawn, with a history row for every change. AI match scores are advisory and never change a status.
- Uploaded resumes are untrusted input, stored privately, and AI output is validated before it is saved.
- Refresh tokens are stored hashed, rotated on use, and a reused token revokes the whole session.

## Database
About 37 tables, created from the entities in `backend/src/CampusQuest.Domain`. Foreign keys use restricted deletes,
indexed strings have bounded lengths, and job and application rows carry a row version for concurrency.
