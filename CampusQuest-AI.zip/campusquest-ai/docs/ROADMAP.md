# Roadmap and status

Statuses are honest: "verified" means it was built and its tests were run; "written, not run" means the code exists but
has not been compiled or executed yet.

| Phase | Scope | Status |
|---|---|---|
| 1 | Architecture, permissions, navigation, database plan | Done (see `ARCHITECTURE.md`) |
| 2 | Frontend shell, design system, public pages, student dashboard on mock data | Verified: 49 tests pass, production build succeeds |
| 3 | Backend solution, database model, Identity authentication, recruiter approval, seed data | Written, not run: needs `dotnet build`, the first migration and `dotnet test` |
| 3b | Connect the Angular app to the API (HTTP services, token refresh) | Not started |
| 4 | Courses, lessons, quizzes with server-side scoring | Not started |
| 5 | XP ledger, badges, missions, leaderboard | Not started |
| 6 | AI resume analysis, career coach, roadmap (with demo mode) | Not started |
| 7 | Jobs, applications, recruiter review, interviews | Not started |
| 8 | Admin portal, notifications, analytics | Not started |
| 9 | Security hardening, accessibility, test coverage | Not started |
| 10 | Docker, Azure deployment guide | Not started |
