# CampusQuest AI — Phase 2 (Angular): frontend shell and student dashboard

Angular 21 (standalone components, signals, reactive forms, RxJS) + TypeScript + Tailwind CSS 4 + Lucide icons + Vitest.
There is **no backend yet**. The app runs on an in-memory mock data layer that is clearly separated from the UI.

## Prerequisites
- Node.js 22.12 or newer (Angular 21 CLI requirement). Check with `node -v`.

## Run it locally
```bash
cd frontend
npm install --legacy-peer-deps   # the flag avoids an npm resolver bug seen on some npm versions
npm start                        # http://localhost:4200
```
Open http://localhost:4200/login and click **Student** under "Preview the app (demo mode)".
(Port 4200 matches the CORS default of the Phase 3 backend.)

## Check it
```bash
npm test -- --watch=false        # 49 tests (Vitest via Angular's unit-test builder)
npm run build                    # production build into frontend/dist/web/browser
```

## Preview every dashboard state
| URL | What you see |
|---|---|
| `/student/dashboard` | Full dashboard with demo data |
| `/student/dashboard?demo=empty` | Brand-new student empty state |
| `/student/dashboard?demo=error` | Error state with a working Try again button |
| `/student/dashboard?demo=loading` | Loading skeleton that stays on screen |

## Data layer (how the real backend plugs in later)
```
src/app/services/models.ts       data shapes (DTOs) shared by the UI and the data layer
src/app/services/contracts.ts    abstract classes = interface + DI token: DashboardService, NotificationService, AuthApi
src/app/mocks/fixtures.ts        all sample data, in one place
src/app/mocks/mock-services.ts   in-memory implementations + provideMockServices()
src/app/app.config.ts            ...provideMockServices()   <- Phase 3: ...provideHttpServices(apiUrl)
```
Pages inject `DashboardService`, `NotificationService` and `AuthApi` and never import a mock. To connect the ASP.NET Core API,
write HTTP implementations of the same three classes and change one line in `app.config.ts`. No page or component changes.
`dashboard.spec.ts` proves this by running the dashboard against a fake service.

Honest behaviour of the mocks:
- Sign-in, registration and password reset are **never faked**. The forms validate, call `AuthApi`, and show that the backend
  is required (the mock throws `ServiceUnavailableError`). Tests assert no success message is shown.
- Notification read/unread changes live in memory only and are labelled "Changes are not saved".
- The role switcher is a **demo preview** (no credentials; only the previewed role is kept in sessionStorage).

## What is on the dashboard
Hero with a level ring and a next-step call to action, four metric cards (XP, streak, learning progress, skills assessed),
today's mission, learning cards (continue learning), recommended learning paths, XP-this-week chart, AI career insight
(labelled illustrative), weekly leaderboard, recent achievements and recommended jobs. Loading, empty and error states,
hover states, keyboard focus styles and responsive layouts (mobile drawer, collapsible sidebar) are included.

## Navigation and links
Every visible link goes to a real route. Pages that are not built yet render an honest "isn't built yet" page that names the
planned phase and has a **Back to dashboard** button. `src/app/testing/link-audit.spec.ts` checks every link on the public pages
and all three role shells against the real route list.

## Level policy
`level = floor(sqrt(totalXp / 50)) + 1` (`src/app/core/xp.ts`, configurable via `LEVEL_XP_FACTOR`). In the real app the server
awards XP and this file only formats progress.

## Not built yet
Courses, quizzes, XP engine, AI features, placements, admin tools and real authentication come in later phases.

## Structure
```
frontend/src/app
  core/       xp policy, roles, nav config, demo role session, guard, toasts, dismiss directive
  services/   models and service contracts
  mocks/      fixtures and mock implementations
  ui/         icon, progress, empty/error states, toaster
  layout/     app shell, sidebar, topbar, breadcrumbs
  pages/      public/, student/dashboard, coming-soon
  testing/    shared test providers and helpers, link audit
```
