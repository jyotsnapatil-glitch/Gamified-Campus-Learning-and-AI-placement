import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideMockServices } from './mocks/mock-services';
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    // Phase 2 runs on in-memory mock services. In Phase 3 this becomes provideHttpServices(apiBaseUrl).
    ...provideMockServices(),
  ],
};
