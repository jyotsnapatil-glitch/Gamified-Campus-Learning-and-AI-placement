import { Route, Routes } from '@angular/router';
import { Type } from '@angular/core';
import { roleGuard } from './core/auth.guard';
import { NAV } from './core/nav-config';
import { ROLES, Role } from './core/roles';
import { AppShell } from './layout/app-shell';
import { ComingSoon } from './pages/coming-soon';
import { Features } from './pages/public/features';
import { ForgotPassword } from './pages/public/forgot-password';
import { Landing } from './pages/public/landing';
import { Login } from './pages/public/login';
import { NotFound, Unauthorized } from './pages/public/notices';
import { PublicLayout } from './pages/public/public-layout';
import { Register } from './pages/public/register';
import { StudentDashboard } from './pages/student/dashboard';

/** Routes that already have a real page. Everything else renders the honest "not built yet" page. */
const IMPLEMENTED: Record<string, Type<unknown>> = {
  '/student/dashboard': StudentDashboard,
};

function areaRoute(area: Role): Route {
  return {
    path: area,
    component: AppShell,
    canActivate: [roleGuard(area)],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      ...NAV[area].map((item): Route => ({
        path: item.to.split('/')[2],
        component: IMPLEMENTED[item.to] ?? ComingSoon,
        title: `${item.label} · CampusQuest AI`,
        data: { label: item.label, phase: item.phase },
      })),
    ],
  };
}

export const routes: Routes = [
  // App areas first, so the public layout's wildcard never swallows them.
  ...ROLES.map(areaRoute),
  {
    path: '',
    component: PublicLayout,
    children: [
      { path: '', pathMatch: 'full', component: Landing, title: 'CampusQuest AI' },
      { path: 'features', component: Features, title: 'Features · CampusQuest AI' },
      { path: 'login', component: Login, title: 'Log in · CampusQuest AI' },
      { path: 'register', component: Register, title: 'Create account · CampusQuest AI' },
      { path: 'forgot-password', component: ForgotPassword, title: 'Reset password · CampusQuest AI' },
      { path: 'unauthorized', component: Unauthorized, title: 'No access · CampusQuest AI' },
      { path: 'not-found', component: NotFound, title: 'Not found · CampusQuest AI' },
      { path: '**', component: NotFound, title: 'Not found · CampusQuest AI' },
    ],
  },
];
