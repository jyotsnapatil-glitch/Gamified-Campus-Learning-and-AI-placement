import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { Role } from './roles';

/** UI guard only. The API enforces the same rules again on every request (Phase 3). */
export function roleGuard(area: Role): CanActivateFn {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);
    const role = auth.role();
    if (!role) return router.createUrlTree(['/login']);
    if (role !== area) return router.createUrlTree(['/unauthorized']);
    return true;
  };
}
