import { Injectable, computed, signal } from '@angular/core';
import { ROLES, Role } from './roles';

const KEY = 'cq_demo_role';
const NAMES: Record<Role, string> = { student: 'Jyotsna Patil', recruiter: 'Riya Shah', admin: 'Placement Admin' };

/**
 * DEMO AUTH (Phase 2). There is no backend yet, so this only remembers which role you are previewing.
 * Phase 3 replaces it with ASP.NET Core Identity: short-lived access token in memory plus an HttpOnly refresh cookie.
 * No tokens or credentials are stored here.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly _role = signal<Role | null>(this.read());

  readonly role = this._role.asReadonly();
  readonly isSignedIn = computed(() => this._role() !== null);
  readonly displayName = computed(() => {
    const r = this._role();
    return r ? NAMES[r] : '';
  });

  signIn(role: Role): void {
    try { sessionStorage.setItem(KEY, role); } catch { /* storage unavailable */ }
    this._role.set(role);
  }

  signOut(): void {
    try { sessionStorage.removeItem(KEY); } catch { /* storage unavailable */ }
    this._role.set(null);
  }

  private read(): Role | null {
    try {
      const v = sessionStorage.getItem(KEY);
      return ROLES.find((r) => r === v) ?? null;
    } catch {
      return null;
    }
  }
}
