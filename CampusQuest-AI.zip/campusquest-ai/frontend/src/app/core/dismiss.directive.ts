import { Directive, ElementRef, HostListener, inject, input, output } from '@angular/core';

/** Emits `dismiss` on outside click or Escape while `appDismiss` is true. */
@Directive({ selector: '[appDismiss]' })
export class DismissDirective {
  readonly active = input(false, { alias: 'appDismiss' });
  readonly dismiss = output<void>();
  private readonly el = inject<ElementRef<HTMLElement>>(ElementRef);

  @HostListener('document:mousedown', ['$event'])
  onDocumentMouseDown(e: MouseEvent) {
    if (this.active() && !this.el.nativeElement.contains(e.target as Node)) this.dismiss.emit();
  }

  @HostListener('document:keydown.escape')
  onEscape() {
    if (this.active()) this.dismiss.emit();
  }
}
