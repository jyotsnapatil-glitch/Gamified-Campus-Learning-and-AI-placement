import { Role } from './roles';

export interface NavItem {
  label: string;
  to: string;
  /** Lucide icon name. */
  icon: string;
  section?: string;
  /** Build phase in which the real page ships (shown on placeholder pages). */
  phase: number;
}

export const NAV: Record<Role, NavItem[]> = {
  student: [
    { label: 'Dashboard', to: '/student/dashboard', icon: 'LayoutDashboard', phase: 2 },
    { label: 'Learning', to: '/student/learning', icon: 'BookOpen', section: 'Learn', phase: 4 },
    { label: 'Skills', to: '/student/skills', icon: 'Target', section: 'Learn', phase: 4 },
    { label: 'Achievements', to: '/student/achievements', icon: 'Trophy', section: 'Play', phase: 5 },
    { label: 'Missions', to: '/student/missions', icon: 'Flag', section: 'Play', phase: 5 },
    { label: 'Leaderboard', to: '/student/leaderboard', icon: 'ChartColumn', section: 'Play', phase: 5 },
    { label: 'Resume analysis', to: '/student/resume-analysis', icon: 'FileText', section: 'AI career', phase: 6 },
    { label: 'Career coach', to: '/student/career-coach', icon: 'Sparkles', section: 'AI career', phase: 6 },
    { label: 'Roadmap', to: '/student/roadmap', icon: 'Map', section: 'AI career', phase: 6 },
    { label: 'Jobs', to: '/student/jobs', icon: 'Briefcase', section: 'Placements', phase: 7 },
    { label: 'Applications', to: '/student/applications', icon: 'ClipboardList', section: 'Placements', phase: 7 },
    { label: 'Interviews', to: '/student/interviews', icon: 'CalendarDays', section: 'Placements', phase: 7 },
  ],
  recruiter: [
    { label: 'Dashboard', to: '/recruiter/dashboard', icon: 'LayoutDashboard', phase: 7 },
    { label: 'Jobs', to: '/recruiter/jobs', icon: 'Briefcase', phase: 7 },
    { label: 'Candidates', to: '/recruiter/candidates', icon: 'Users', phase: 7 },
  ],
  admin: [
    { label: 'Dashboard', to: '/admin/dashboard', icon: 'LayoutDashboard', phase: 8 },
    { label: 'Users', to: '/admin/users', icon: 'Users', phase: 8 },
    { label: 'Courses', to: '/admin/courses', icon: 'GraduationCap', phase: 8 },
    { label: 'Quizzes', to: '/admin/quizzes', icon: 'ClipboardList', phase: 8 },
    { label: 'Missions', to: '/admin/missions', icon: 'Flag', phase: 8 },
    { label: 'Placements', to: '/admin/placements', icon: 'Briefcase', phase: 8 },
    { label: 'Analytics', to: '/admin/analytics', icon: 'ChartColumn', phase: 8 },
    { label: 'Audit logs', to: '/admin/audit-logs', icon: 'ScrollText', phase: 8 },
  ],
};

export const ALL_NAV_ITEMS: NavItem[] = [...NAV.student, ...NAV.recruiter, ...NAV.admin];
