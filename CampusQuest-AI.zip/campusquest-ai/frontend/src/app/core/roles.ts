export type Role = 'student' | 'recruiter' | 'admin';

export const ROLES: Role[] = ['student', 'recruiter', 'admin'];

export const ROLE_LABEL: Record<Role, string> = {
  student: 'Student',
  recruiter: 'Recruiter',
  admin: 'Admin',
};

export const ROLE_HOME: Record<Role, string> = {
  student: '/student/dashboard',
  recruiter: '/recruiter/dashboard',
  admin: '/admin/dashboard',
};
