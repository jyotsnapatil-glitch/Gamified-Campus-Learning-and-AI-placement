import { Injectable, signal } from '@angular/core';

export interface Toast {
  id: number;
  kind: 'info' | 'success';
  message: string;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  private nextId = 1;
  readonly toasts = signal<Toast[]>([]);

  info(message: string) { this.push('info', message); }
  success(message: string) { this.push('success', message); }
  dismiss(id: number) { this.toasts.update((l) => l.filter((t) => t.id !== id)); }

  private push(kind: Toast['kind'], message: string) {
    const id = this.nextId++;
    this.toasts.update((l) => [...l, { id, kind, message }]);
    setTimeout(() => this.dismiss(id), 6000);
  }
}
