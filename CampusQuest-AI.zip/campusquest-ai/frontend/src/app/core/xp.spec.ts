import { describe, expect, it } from 'vitest';
import { levelForXp, levelProgress, levelTitle, xpToReachLevel } from './xp';

describe('level policy', () => {
  it('starts at level 1 and levels up at the configured thresholds', () => {
    expect(levelForXp(0)).toBe(1);
    expect(levelForXp(49)).toBe(1);
    expect(levelForXp(50)).toBe(2);
    expect(levelForXp(2449)).toBe(7);
    expect(levelForXp(2450)).toBe(8);
  });

  it('never returns a level below 1 for bad input', () => {
    expect(levelForXp(-100)).toBe(1);
  });

  it('computes the XP needed to reach a level', () => {
    expect(xpToReachLevel(1)).toBe(0);
    expect(xpToReachLevel(9)).toBe(3200);
  });

  it('reports progress toward the next level', () => {
    const p = levelProgress(2650);
    expect(p.level).toBe(8);
    expect(p.title).toBe('Explorer');
    expect(p.xpIntoLevel).toBe(200);
    expect(p.xpForLevel).toBe(750);
    expect(p.xpToNext).toBe(550);
    expect(p.percent).toBe(27);
  });

  it('maps levels to titles', () => {
    expect(levelTitle(1)).toBe('Newcomer');
    expect(levelTitle(8)).toBe('Explorer');
    expect(levelTitle(20)).toBe('Expert');
  });
});
