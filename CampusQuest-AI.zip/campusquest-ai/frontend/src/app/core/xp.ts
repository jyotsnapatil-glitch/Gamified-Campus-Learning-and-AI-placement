/**
 * Level policy (configurable). Total XP needed to REACH level L is FACTOR * (L - 1)^2.
 * The real XP award rules live on the backend (Phase 5); this file only formats progress in the UI.
 */
export const LEVEL_XP_FACTOR = 50;

export function levelForXp(totalXp: number): number {
  return Math.floor(Math.sqrt(Math.max(0, totalXp) / LEVEL_XP_FACTOR)) + 1;
}

export function xpToReachLevel(level: number): number {
  return LEVEL_XP_FACTOR * (level - 1) ** 2;
}

export function levelTitle(level: number): string {
  if (level <= 2) return 'Newcomer';
  if (level <= 5) return 'Learner';
  if (level <= 10) return 'Explorer';
  if (level <= 15) return 'Builder';
  return 'Expert';
}

export interface LevelProgress {
  level: number;
  title: string;
  xpIntoLevel: number;
  xpForLevel: number;
  xpToNext: number;
  percent: number;
}

export function levelProgress(totalXp: number): LevelProgress {
  const level = levelForXp(totalXp);
  const start = xpToReachLevel(level);
  const next = xpToReachLevel(level + 1);
  const xpIntoLevel = totalXp - start;
  const xpForLevel = next - start;
  return {
    level,
    title: levelTitle(level),
    xpIntoLevel,
    xpForLevel,
    xpToNext: next - totalXp,
    percent: Math.round((xpIntoLevel / xpForLevel) * 100),
  };
}
