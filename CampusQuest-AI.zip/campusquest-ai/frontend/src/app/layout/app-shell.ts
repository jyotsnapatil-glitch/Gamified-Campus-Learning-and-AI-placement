import { Component, inject, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from '../core/auth.service';

import { Breadcrumbs } from './breadcrumbs';
import { Sidebar } from './sidebar';
import { Topbar } from './topbar';

@Component({
  selector: 'app-shell',
  imports: [RouterOutlet, Sidebar, Topbar, Breadcrumbs],
  template: `
    @if (auth.role(); as role) {
      <div class="flex h-full bg-canvas">
        <a href="#main" class="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded-md focus:bg-white focus:px-3 focus:py-2">Skip to content</a>
        <app-sidebar [role]="role" [collapsed]="collapsed()" [mobileOpen]="mobileOpen()" (closeMobile)="mobileOpen.set(false)" />
        <div class="flex min-w-0 flex-1 flex-col">
          <app-topbar [role]="role" (openMobile)="mobileOpen.set(true)" (toggleCollapse)="collapsed.set(!collapsed())" />
          <main id="main" class="flex-1 overflow-y-auto p-4 lg:p-8">
            <div class="mx-auto max-w-6xl">
              <app-breadcrumbs />
              <router-outlet />
            </div>
          </main>
        </div>
      </div>
    }
  `,
})
export class AppShell {
  protected readonly auth = inject(AuthService);
  protected readonly collapsed = signal(false);
  protected readonly mobileOpen = signal(false);
}
