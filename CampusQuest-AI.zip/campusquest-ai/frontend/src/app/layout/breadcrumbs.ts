import { Component, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { filter, map, startWith } from 'rxjs/operators';
import { ALL_NAV_ITEMS } from '../core/nav-config';
import { ROLE_HOME, ROLE_LABEL, Role } from '../core/roles';
import { Icon } from '../ui/icon';

function titleCase(s: string) {
  const t = s.replace(/-/g, ' ');
  return t.charAt(0).toUpperCase() + t.slice(1);
}

@Component({
  selector: 'app-breadcrumbs',
  imports: [RouterLink, Icon],
  template: `
    @if (view(); as v) {
      <nav aria-label="Breadcrumb" class="mb-4 text-sm text-slate-500">
        <ol class="flex flex-wrap items-center gap-1">
          <li><a [routerLink]="v.homePath" class="hover:text-slate-800">{{ v.areaLabel }}</a></li>
          @for (c of v.crumbs; track c.path; let last = $last) {
            <li class="flex items-center gap-1">
              <app-icon name="ChevronRight" [size]="14" />
              @if (last) {
                <span aria-current="page" class="font-medium text-slate-800">{{ c.label }}</span>
              } @else {
                <a [routerLink]="c.path" class="hover:text-slate-800">{{ c.label }}</a>
              }
            </li>
          }
        </ol>
      </nav>
    }
  `,
})
export class Breadcrumbs {
  private readonly router = inject(Router);
  private readonly url = toSignal(
    this.router.events.pipe(
      filter((e) => e instanceof NavigationEnd),
      map(() => this.router.url),
      startWith(this.router.url),
    ),
    { initialValue: this.router.url },
  );

  protected readonly view = computed(() => {
    const segments = this.url().split('?')[0].split('/').filter(Boolean);
    if (segments.length < 2 || segments[segments.length - 1] === 'dashboard') return null;
    const area = segments[0] as Role;
    const crumbs = segments.slice(1).map((seg, i) => {
      const path = '/' + segments.slice(0, i + 2).join('/');
      return { path, label: ALL_NAV_ITEMS.find((n) => n.to === path)?.label ?? titleCase(seg) };
    });
    return { areaLabel: ROLE_LABEL[area] ?? 'Home', homePath: ROLE_HOME[area] ?? '/', crumbs };
  });
}
