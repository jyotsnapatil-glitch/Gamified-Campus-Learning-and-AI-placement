import { beforeEach, describe, expect, it } from 'vitest';
import { openApp } from '../testing/open-app';

const navText = (root: HTMLElement) => root.querySelector('nav[aria-label="Main navigation"]')?.textContent ?? '';

describe('role-specific navigation and guards', () => {
  beforeEach(() => sessionStorage.clear());

  it('shows student-only links to students', async () => {
    const { root, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText('Total XP');
    expect(navText(root)).toContain('Leaderboard');
    expect(navText(root)).not.toContain('Audit logs');
  });

  it('shows recruiter links to recruiters', async () => {
    const { root, waitForText } = await openApp('/recruiter/dashboard', 'recruiter');
    await waitForText("isn't built yet");
    expect(navText(root)).toContain('Candidates');
    expect(navText(root)).not.toContain('Learning');
  });

  it('shows admin links to admins', async () => {
    const { root, waitForText } = await openApp('/admin/dashboard', 'admin');
    await waitForText("isn't built yet");
    expect(navText(root)).toContain('Audit logs');
  });

  it('sends signed-out visitors to the login page', async () => {
    const { waitForText } = await openApp('/student/dashboard', null);
    await waitForText('Preview the app (demo mode)');
  });

  it('blocks a student from the admin area', async () => {
    const { waitForText } = await openApp('/admin/users', 'student');
    await waitForText("You don't have access to this page");
  });

  it('marks unbuilt pages honestly and offers a way back', async () => {
    const { root, text, waitForText } = await openApp('/student/learning', 'student');
    await waitForText("Learning isn't built yet");
    expect(text()).toContain('Planned · Phase 4');
    const back = Array.from(root.querySelectorAll('a')).find((a) => a.textContent?.trim() === 'Back to dashboard');
    expect(back?.getAttribute('href')).toBe('/student/dashboard');
  });

  it('shows a not-found page for unknown routes', async () => {
    const { waitForText } = await openApp('/no/such/page', null);
    await waitForText('Page not found');
  });
});
