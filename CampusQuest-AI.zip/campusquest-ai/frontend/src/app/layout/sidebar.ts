import { Component, computed, input, output } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { NAV, NavItem } from '../core/nav-config';
import { Role } from '../core/roles';
import { Icon } from '../ui/icon';

@Component({
  selector: 'app-sidebar',
  imports: [RouterLink, RouterLinkActive, Icon],
  template: `
    @if (mobileOpen()) {
      <div class="fixed inset-0 z-30 bg-black/40 lg:hidden" (click)="closeMobile.emit()" aria-hidden="true"></div>
    }
    <aside
      class="fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-navy-900 text-slate-300 transition-transform duration-200 lg:static lg:translate-x-0"
      [class]="asideClass()"
    >
      <div class="flex h-16 items-center justify-between px-4">
        <div class="flex items-center gap-2 text-white">
          <span class="rounded-lg bg-brand-600 p-1.5"><app-icon name="Rocket" /></span>
          <span class="text-base font-semibold" [class]="labelClass()">CampusQuest</span>
        </div>
        <button type="button" (click)="closeMobile.emit()" aria-label="Close menu" class="rounded-md p-1 text-slate-400 hover:bg-navy-800 lg:hidden">
          <app-icon name="X" />
        </button>
      </div>

      <nav aria-label="Main navigation" class="flex-1 space-y-4 overflow-y-auto px-3 py-2">
        @for (g of groups(); track g.section) {
          <div>
            @if (g.section) {
              <p class="px-3 pb-1 text-xs font-medium uppercase tracking-wide text-slate-500" [class]="labelClass()">{{ g.section }}</p>
            }
            <ul class="space-y-1">
              @for (item of g.items; track item.to) {
                <li>
                  <a
                    [routerLink]="item.to"
                    routerLinkActive="bg-navy-700 text-white"
                    (click)="closeMobile.emit()"
                    [attr.title]="collapsed() ? item.label : null"
                    class="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors hover:bg-navy-800 hover:text-white"
                    [class.lg:justify-center]="collapsed()"
                  >
                    <app-icon [name]="item.icon" />
                    <span [class]="labelClass()">{{ item.label }}</span>
                  </a>
                </li>
              }
            </ul>
          </div>
        }
      </nav>

      <div class="m-3 rounded-lg bg-navy-800 p-3 text-xs text-slate-400" [class]="labelClass()">
        Demo mode: sample data, no backend connected yet.
      </div>
    </aside>
  `,
})
export class Sidebar {
  readonly role = input.required<Role>();
  readonly collapsed = input(false);
  readonly mobileOpen = input(false);
  readonly closeMobile = output<void>();

  protected readonly labelClass = computed(() => (this.collapsed() ? 'lg:sr-only' : ''));
  protected readonly asideClass = computed(() =>
    [this.mobileOpen() ? 'translate-x-0' : '-translate-x-full', this.collapsed() ? 'lg:w-[76px]' : 'lg:w-64'].join(' '),
  );

  protected readonly groups = computed(() => {
    const groups: { section: string; items: NavItem[] }[] = [];
    for (const item of NAV[this.role()]) {
      const name = item.section ?? '';
      const last = groups[groups.length - 1];
      if (last && last.section === name) last.items.push(item);
      else groups.push({ section: name, items: [item] });
    }
    return groups;
  });
}
