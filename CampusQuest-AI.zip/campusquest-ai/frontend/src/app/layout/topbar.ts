import { Component, DestroyRef, computed, inject, input, output, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../core/auth.service';
import { DismissDirective } from '../core/dismiss.directive';
import { NAV } from '../core/nav-config';
import { ROLES, ROLE_HOME, ROLE_LABEL, Role } from '../core/roles';
import { NotificationService } from '../services/contracts';
import { AppNotification } from '../services/models';
import { Icon } from '../ui/icon';

@Component({
  selector: 'app-topbar',
  imports: [RouterLink, Icon, DismissDirective],
  template: `
    <header class="flex h-16 shrink-0 items-center gap-2 border-b border-slate-200 bg-white px-3 lg:px-6">
      <button type="button" (click)="openMobile.emit()" aria-label="Open menu" class="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden">
        <app-icon name="Menu" [size]="20" />
      </button>
      <button type="button" (click)="toggleCollapse.emit()" aria-label="Collapse or expand sidebar" class="hidden rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:block">
        <app-icon name="PanelLeft" [size]="20" />
      </button>

      <div class="relative hidden w-72 md:block" [appDismiss]="matches().length > 0 || query().trim().length > 0" (dismiss)="query.set('')">
        <span class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"><app-icon name="Search" [size]="16" /></span>
        <input
          type="search"
          aria-label="Search pages"
          placeholder="Search pages"
          [value]="query()"
          (input)="query.set($any($event.target).value)"
          (keydown.enter)="goFirst()"
          class="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm placeholder:text-slate-400"
        />
        @if (query().trim()) {
          <ul class="absolute left-0 right-0 top-full z-20 mt-1 rounded-lg border border-slate-200 bg-white p-1 shadow-lg">
            @if (matches().length === 0) { <li class="px-3 py-2 text-sm text-slate-500">No matching pages</li> }
            @for (m of matches(); track m.to) {
              <li>
                <button type="button" (click)="go(m.to)" class="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm hover:bg-slate-50">
                  <app-icon [name]="m.icon" [size]="16" /> {{ m.label }}
                </button>
              </li>
            }
          </ul>
        }
      </div>

      <div class="ml-auto flex items-center gap-1">
        <a routerLink="/features" class="hidden px-3 text-sm text-slate-500 hover:text-slate-800 sm:block">Help</a>

        <div class="relative" [appDismiss]="notifOpen()" (dismiss)="notifOpen.set(false)">
          <button type="button" (click)="notifOpen.set(!notifOpen())" [attr.aria-expanded]="notifOpen()"
                  [attr.aria-label]="'Notifications, ' + unread() + ' unread'" class="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100">
            <app-icon name="Bell" />
            @if (unread() > 0) {
              <span class="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand-600 px-1 text-[10px] font-semibold text-white">{{ unread() }}</span>
            }
          </button>
          @if (notifOpen()) {
            <div class="absolute right-0 z-20 mt-2 w-80 rounded-xl border border-slate-200 bg-white p-2 shadow-lg">
              <div class="flex items-center justify-between px-2 py-1">
                <p class="text-sm font-semibold">Notifications</p>
                <button type="button" [disabled]="unread() === 0" class="text-xs text-brand-600 hover:underline disabled:text-slate-400 disabled:no-underline" (click)="markAllRead()">Mark all read</button>
              </div>
              @if (notifications().length === 0) { <p class="px-2 py-4 text-sm text-slate-500">You're all caught up.</p> }
              <ul>
                @for (n of notifications(); track n.id) {
                  <li>
                    <button type="button" (click)="openNotification(n)" class="flex w-full items-start gap-2 rounded-lg px-2 py-2 text-left text-sm hover:bg-slate-50">
                      <span class="mt-1.5 h-2 w-2 shrink-0 rounded-full" [class]="n.read ? 'bg-transparent' : 'bg-brand-600'"></span>
                      <span [class]="n.read ? 'text-slate-500' : 'font-medium text-slate-900'">{{ n.title }}</span>
                    </button>
                  </li>
                }
              </ul>
              <p class="px-2 pt-1 text-xs text-slate-400">Demo notifications. Changes are not saved.</p>
            </div>
          }
        </div>

        <div class="relative" [appDismiss]="menuOpen()" (dismiss)="menuOpen.set(false)">
          <button type="button" (click)="menuOpen.set(!menuOpen())" [attr.aria-expanded]="menuOpen()" aria-label="Account menu"
                  class="flex items-center gap-2 rounded-lg p-1 pr-2 hover:bg-slate-100">
            <span class="flex h-8 w-8 items-center justify-center rounded-full bg-brand-600 text-xs font-semibold text-white">{{ initials() }}</span>
            <span class="hidden text-left text-sm sm:block">
              <span class="block font-medium leading-4">{{ auth.displayName() }}</span>
              <span class="block text-xs text-slate-500">{{ roleLabel() }}</span>
            </span>
            <app-icon name="ChevronDown" [size]="14" />
          </button>
          @if (menuOpen()) {
            <div class="absolute right-0 z-20 mt-2 w-56 rounded-xl border border-slate-200 bg-white p-2 shadow-lg">
              <p class="px-2 pb-1 text-xs font-medium uppercase tracking-wide text-slate-400">Preview as (demo)</p>
              @for (r of roles; track r) {
                <button type="button" [disabled]="r === role()" (click)="switchRole(r)"
                        class="block w-full rounded-md px-2 py-1.5 text-left text-sm hover:bg-slate-50 disabled:text-slate-400 disabled:hover:bg-transparent">
                  {{ labels[r] }}
                </button>
              }
              <div class="my-1 border-t border-slate-100"></div>
              <button type="button" (click)="signOut()" class="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm text-red-600 hover:bg-red-50">
                <app-icon name="LogOut" [size]="14" /> Sign out
              </button>
            </div>
          }
        </div>
      </div>
    </header>
  `,
})
export class Topbar {
  readonly role = input.required<Role>();
  readonly openMobile = output<void>();
  readonly toggleCollapse = output<void>();

  protected readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  protected readonly roles = ROLES;
  protected readonly labels = ROLE_LABEL;

  protected readonly query = signal('');
  protected readonly notifOpen = signal(false);
  protected readonly menuOpen = signal(false);
  protected readonly notifications = signal<AppNotification[]>([]);
  private readonly notificationApi = inject(NotificationService);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly roleLabel = computed(() => ROLE_LABEL[this.role()]);
  protected readonly unread = computed(() => this.notifications().filter((n) => !n.read).length);
  protected readonly initials = computed(() =>
    this.auth.displayName().split(' ').map((p) => p[0]).slice(0, 2).join(''),
  );
  protected readonly matches = computed(() => {
    const q = this.query().trim().toLowerCase();
    return q ? NAV[this.role()].filter((i) => i.label.toLowerCase().includes(q)) : [];
  });

  protected go(to: string) {
    this.query.set('');
    void this.router.navigateByUrl(to);
  }
  protected goFirst() {
    const first = this.matches()[0];
    if (first) this.go(first.to);
  }
  constructor() {
    this.loadNotifications();
  }

  private loadNotifications() {
    this.notificationApi.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((items) => this.notifications.set(items));
  }
  protected markAllRead() {
    this.notificationApi.markAllRead().pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.loadNotifications());
  }
  protected openNotification(n: AppNotification) {
    this.notificationApi.markRead(n.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.loadNotifications());
    this.notifOpen.set(false);
    void this.router.navigateByUrl(n.to);
  }
  protected switchRole(r: Role) {
    this.auth.signIn(r);
    this.menuOpen.set(false);
    void this.router.navigateByUrl(ROLE_HOME[r]);
  }
  protected signOut() {
    this.auth.signOut();
    this.menuOpen.set(false);
    void this.router.navigateByUrl('/');
  }
}
