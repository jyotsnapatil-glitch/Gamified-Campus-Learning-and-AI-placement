import { AppNotification, DashboardData } from '../services/models';

/** Sample content for demo mode. Everything here is clearly labelled as demo in the UI. */
export const fullDashboard: DashboardData = {
  isNewStudent: false,
  firstName: 'Jyotsna',
  totalXp: 2650,
  streakDays: 7,
  learningProgressPercent: 68,
  skillsAssessed: 5,
  skillsTotal: 8,
  mission: {
    title: 'Your next recommended activity',
    description: 'Complete a SQL joins challenge and score at least 80% on the quiz.',
    xp: 100,
    tasksDone: 1,
    tasksTotal: 3,
  },
  insight: {
    text: 'Your latest assessment suggests focusing on SQL joins and REST API fundamentals before advancing to the next backend learning path.',
  },
  continueLearning: [
    { id: 1, title: 'SQL Mastery', moduleLabel: 'Module 4 of 8', level: 'Intermediate', percent: 50 },
    { id: 2, title: 'ASP.NET Core Web API', moduleLabel: 'Module 2 of 10', level: 'Intermediate', percent: 20 },
  ],
  recommendedPaths: [
    { id: 1, title: '.NET Backend Developer', description: 'C#, ASP.NET Core, EF Core and REST API design.', level: 'Intermediate', lessons: 42, hours: 28 },
    { id: 2, title: 'Data Structures Essentials', description: 'Arrays, trees, graphs and complexity for interviews.', level: 'Beginner', lessons: 30, hours: 20 },
    { id: 3, title: 'Interview Preparation', description: 'Behavioural, system design and coding round practice.', level: 'Advanced', lessons: 18, hours: 12 },
  ],
  weeklyXp: [
    { day: 'Mon', xp: 120 },
    { day: 'Tue', xp: 80 },
    { day: 'Wed', xp: 150 },
    { day: 'Thu', xp: 0 },
    { day: 'Fri', xp: 200 },
    { day: 'Sat', xp: 110 },
    { day: 'Sun', xp: 120 },
  ],
  leaderboard: [
    { rank: 1, name: 'Aarav M.', xp: 910, isYou: false },
    { rank: 2, name: 'Isha K.', xp: 840, isYou: false },
    { rank: 3, name: 'You', xp: 780, isYou: true },
    { rank: 4, name: 'Rohan D.', xp: 720, isYou: false },
  ],
  achievements: [
    { id: 1, name: 'First steps', description: 'Completed your first assessment' },
    { id: 2, name: '7-day streak', description: 'Learned seven days in a row' },
    { id: 3, name: 'Quiz ace', description: 'Scored 100% on a quiz' },
  ],
  recommendedJobs: [
    { id: 1, title: '.NET Intern', company: 'Demo Company A', location: 'Pune' },
    { id: 2, title: 'Full-stack Intern', company: 'Demo Company B', location: 'Remote' },
  ],
};

export const newStudentDashboard: DashboardData = {
  ...fullDashboard,
  isNewStudent: true,
  totalXp: 0,
  streakDays: 0,
  learningProgressPercent: 0,
  skillsAssessed: 0,
  continueLearning: [],
  weeklyXp: fullDashboard.weeklyXp.map((d) => ({ ...d, xp: 0 })),
  leaderboard: [],
  achievements: [],
  recommendedJobs: [],
};

export const initialNotifications: AppNotification[] = [
  { id: 1, title: 'Badge earned: 7-day streak', to: '/student/achievements', read: false },
  { id: 2, title: 'New job: .NET Intern', to: '/student/jobs', read: false },
  { id: 3, title: 'Mission progress: 1 of 3 tasks done', to: '/student/missions', read: true },
];
