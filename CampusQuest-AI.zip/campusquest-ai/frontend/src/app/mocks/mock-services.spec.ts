import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { describe, expect, it } from 'vitest';
import { AuthApi, DashboardService, NotificationService, ServiceUnavailableError } from '../services/contracts';
import { testProviders } from '../testing/test-providers';

function services() {
  TestBed.configureTestingModule({ providers: testProviders() });
  return {
    dashboard: TestBed.inject(DashboardService),
    notifications: TestBed.inject(NotificationService),
    auth: TestBed.inject(AuthApi),
  };
}

describe('mock dashboard service', () => {
  it('returns the full dashboard by default', async () => {
    const data = await firstValueFrom(services().dashboard.getDashboard());
    expect(data.isNewStudent).toBe(false);
    expect(data.continueLearning.length).toBeGreaterThan(0);
  });

  it('returns a new-student dashboard for the empty scenario', async () => {
    const data = await firstValueFrom(services().dashboard.getDashboard({ scenario: 'empty' }));
    expect(data.isNewStudent).toBe(true);
    expect(data.totalXp).toBe(0);
  });

  it('fails for the error scenario', async () => {
    await expect(firstValueFrom(services().dashboard.getDashboard({ scenario: 'error' }))).rejects.toThrow(/could not be reached/);
  });
});

describe('mock notification service', () => {
  it('marks a single notification as read', async () => {
    const s = services().notifications;
    expect((await firstValueFrom(s.list())).filter((n) => !n.read)).toHaveLength(2);
    await firstValueFrom(s.markRead(1));
    expect((await firstValueFrom(s.list())).filter((n) => !n.read)).toHaveLength(1);
  });

  it('marks everything read', async () => {
    const s = services().notifications;
    await firstValueFrom(s.markAllRead());
    expect((await firstValueFrom(s.list())).every((n) => n.read)).toBe(true);
  });
});

describe('mock auth api', () => {
  it('never pretends to sign in or create accounts', async () => {
    const { auth } = services();
    await expect(firstValueFrom(auth.signIn({ email: 'a@b.co', password: 'x' }))).rejects.toBeInstanceOf(ServiceUnavailableError);
    await expect(firstValueFrom(auth.register({ fullName: 'A B', email: 'a@b.co', role: 'student', password: 'Passw0rd1' }))).rejects.toBeInstanceOf(ServiceUnavailableError);
    await expect(firstValueFrom(auth.requestPasswordReset('a@b.co'))).rejects.toBeInstanceOf(ServiceUnavailableError);
  });
});
