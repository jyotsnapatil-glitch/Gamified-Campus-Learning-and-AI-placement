import { Injectable, InjectionToken, Provider, inject } from '@angular/core';
import { Observable, defer, of, throwError, timer } from 'rxjs';
import { delay, map, mergeMap } from 'rxjs/operators';
import { AuthApi, DashboardService, NotificationService, ServiceUnavailableError } from '../services/contracts';
import { AppNotification, DashboardData, DashboardQuery } from '../services/models';
import { fullDashboard, initialNotifications, newStudentDashboard } from './fixtures';

/** Simulated network latency in ms. Tests set this to 0. */
export const MOCK_LATENCY_MS = new InjectionToken<number>('MOCK_LATENCY_MS', { providedIn: 'root', factory: () => 700 });

const BACKEND_MESSAGE = 'needs the backend, which arrives in Phase 3. Use a demo role to preview the app.';

@Injectable()
export class MockDashboardService extends DashboardService {
  private readonly latency = inject(MOCK_LATENCY_MS);

  getDashboard(query?: DashboardQuery): Observable<DashboardData> {
    const scenario = query?.scenario;
    if (scenario === 'loading') return timer(60_000).pipe(map(() => fullDashboard)); // stays on the loading skeleton
    if (scenario === 'error') {
      return timer(this.latency).pipe(
        mergeMap(() => throwError(() => new Error('Demo error: the server could not be reached.'))),
      );
    }
    return of(scenario === 'empty' ? newStudentDashboard : fullDashboard).pipe(delay(this.latency));
  }
}

/** In-memory only: changes last until the page reloads. Nothing is persisted. */
@Injectable()
export class MockNotificationService extends NotificationService {
  private readonly latency = inject(MOCK_LATENCY_MS);
  private items: AppNotification[] = initialNotifications.map((n) => ({ ...n }));

  list(): Observable<AppNotification[]> {
    return defer(() => of(this.items.map((n) => ({ ...n })))).pipe(delay(this.latency / 4));
  }

  markRead(id: number): Observable<void> {
    return defer(() => {
      this.items = this.items.map((n) => (n.id === id ? { ...n, read: true } : n));
      return of(undefined);
    });
  }

  markAllRead(): Observable<void> {
    return defer(() => {
      this.items = this.items.map((n) => ({ ...n, read: true }));
      return of(undefined);
    });
  }
}

/** Never fakes success: every call tells the user the backend is required. */
@Injectable()
export class MockAuthApi extends AuthApi {
  signIn(): Observable<void> {
    return throwError(() => new ServiceUnavailableError('Sign-in ' + BACKEND_MESSAGE));
  }
  register(): Observable<void> {
    return throwError(() => new ServiceUnavailableError('Account creation ' + BACKEND_MESSAGE));
  }
  requestPasswordReset(): Observable<void> {
    return throwError(() => new ServiceUnavailableError('Password reset ' + BACKEND_MESSAGE));
  }
}

/** Phase 3: replace this with provideHttpServices() that returns the same three bindings. */
export function provideMockServices(): Provider[] {
  return [
    { provide: DashboardService, useClass: MockDashboardService },
    { provide: NotificationService, useClass: MockNotificationService },
    { provide: AuthApi, useClass: MockAuthApi },
  ];
}
