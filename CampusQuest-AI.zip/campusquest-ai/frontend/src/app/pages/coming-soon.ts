import { Component, computed, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../core/auth.service';
import { ROLE_HOME } from '../core/roles';
import { Icon } from '../ui/icon';

/** Honest placeholder: the route, role check and navigation work, the feature itself is not built yet. */
@Component({
  selector: 'app-coming-soon',
  imports: [Icon, RouterLink],
  template: `
    <div class="card flex flex-col items-center gap-3 py-16 text-center">
      <span class="rounded-full bg-amber-50 p-3 text-amber-600"><app-icon name="Hammer" [size]="24" /></span>
      <h1 class="text-xl font-semibold">{{ label }} isn't built yet</h1>
      <p class="max-w-md text-sm text-slate-600">
        The route, role check and navigation are in place so you can test access control now. The feature itself is planned for build phase {{ phase }}.
      </p>
      <span class="badge badge-warning">Planned · Phase {{ phase }}</span>
      @if (home(); as path) {
        <a [routerLink]="path" class="btn btn-secondary mt-2">Back to dashboard</a>
      }
    </div>
  `,
})
export class ComingSoon {
  private readonly data = inject(ActivatedRoute).snapshot.data;
  private readonly auth = inject(AuthService);
  protected readonly label: string = this.data['label'] ?? 'This page';
  protected readonly phase: number | string = this.data['phase'] ?? '?';
  protected readonly home = computed(() => {
    const r = this.auth.role();
    return r ? ROLE_HOME[r] : null;
  });
}
