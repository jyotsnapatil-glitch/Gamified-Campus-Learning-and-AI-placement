import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-features',
  imports: [RouterLink],
  template: `
    <div class="mx-auto max-w-6xl px-4 py-16">
      <h1 class="text-3xl font-semibold tracking-tight">Features</h1>
      <p class="mt-2 max-w-2xl text-slate-600">What CampusQuest AI is designed to do. Features ship in phases, and unfinished screens are clearly marked inside the app.</p>
      <div class="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        @for (f of features; track f.title) {
          <div class="card">
            <h2 class="font-semibold">{{ f.title }}</h2>
            <p class="mt-1 text-sm text-slate-600">{{ f.text }}</p>
          </div>
        }
      </div>
      <a routerLink="/register" class="btn btn-primary mt-8">Get started</a>
    </div>
  `,
})
export class Features {
  protected readonly features = [
    { title: 'Learning management', text: 'Courses, modules, lessons and quizzes with saved progress and attempt history.' },
    { title: 'Skill verification', text: 'Every skill shows its evidence: self-declared, quiz-assessed, challenge or course completion.' },
    { title: 'Gamification', text: 'XP, levels, badges, streaks and missions, all awarded and checked on the server.' },
    { title: 'AI resume analysis', text: 'Compare a resume with a job description and get an explainable match with concrete improvements.' },
    { title: 'Career roadmap', text: 'A structured, trackable plan built from your skills, assessments and target role.' },
    { title: 'Placements', text: 'Job posts with eligibility rules, applications, status tracking and interview scheduling.' },
  ];
}
