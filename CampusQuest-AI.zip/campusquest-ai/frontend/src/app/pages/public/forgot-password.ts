import { Component, inject, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ToastService } from '../../core/toast.service';
import { AuthApi } from '../../services/contracts';
import { emailFormat } from './validators';

@Component({
  selector: 'app-forgot-password',
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="mx-auto max-w-md px-4 py-16">
      <div class="card p-6">
        <h1 class="text-xl font-semibold">Reset your password</h1>
        <p class="mt-1 text-sm text-slate-600">Enter your email and we'll send reset instructions once email delivery is configured.</p>
        <form [formGroup]="form" (ngSubmit)="submit()" novalidate class="mt-4 space-y-4">
          <div>
            <label for="email" class="field-label">Email</label>
            <input id="email" type="email" autocomplete="email" formControlName="email" class="field-input" [class.invalid]="showError()" />
            @if (showError()) {
              <p role="alert" class="field-error">{{ form.controls.email.hasError('required') ? 'Enter your email' : 'Enter a valid email address' }}</p>
            }
          </div>
          <button type="submit" class="btn btn-primary w-full">Send reset link</button>
        </form>
        <p class="mt-4 text-sm"><a routerLink="/login" class="text-brand-600 hover:underline">Back to log in</a></p>
      </div>
    </div>
  `,
})
export class ForgotPassword {
  private readonly toast = inject(ToastService);
  private readonly authApi = inject(AuthApi);
  private readonly submitted = signal(false);
  protected readonly form = inject(NonNullableFormBuilder).group({ email: ['', [Validators.required, emailFormat]] });

  protected showError() {
    const c = this.form.controls.email;
    return c.invalid && (c.touched || this.submitted());
  }

  protected submit() {
    this.submitted.set(true);
    this.form.markAllAsTouched();
    if (this.form.invalid) return;
    this.authApi.requestPasswordReset(this.form.getRawValue().email).subscribe({
      next: () => this.toast.success('If that email is registered, reset instructions are on their way.'),
      error: (e: unknown) => this.toast.info(e instanceof Error ? e.message : 'Could not send reset instructions.'),
    });
  }
}
