import { TestBed } from '@angular/core/testing';
import { ToastService } from '../../core/toast.service';
import { testProviders } from '../../testing/test-providers';
import { AuthApi, ServiceUnavailableError } from '../../services/contracts';
import { throwError } from 'rxjs';
import { beforeEach, describe, expect, it } from 'vitest';
import { Login } from './login';
import { Register } from './register';

function setup<T>(component: new () => T) {
  const fixture = TestBed.createComponent(component);
  fixture.detectChanges();
  const el = fixture.nativeElement as HTMLElement;
  const type = (id: string, value: string) => {
    const input = el.querySelector<HTMLInputElement>('#' + id)!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  };
  const select = (id: string, value: string) => {
    const s = el.querySelector<HTMLSelectElement>('#' + id)!;
    s.value = value;
    s.dispatchEvent(new Event('change'));
  };
  const submit = () => {
    el.querySelector<HTMLFormElement>('form')!.dispatchEvent(new Event('submit'));
    fixture.detectChanges();
  };
  return { fixture, el, type, select, submit };
}

describe('forms', () => {
  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({ providers: testProviders() });
  });

  describe('login', () => {
    it('shows required-field errors on empty submit', () => {
      const { el, submit } = setup(Login);
      submit();
      expect(el.textContent).toContain('Enter your email');
      expect(el.textContent).toContain('Enter your password');
    });

    it('rejects an invalid email address', () => {
      const { el, type, submit } = setup(Login);
      type('email', 'not-an-email');
      type('password', 'secret123');
      submit();
      expect(el.textContent).toContain('Enter a valid email address');
    });

    it('accepts a valid form without errors', () => {
      const { el, type, submit } = setup(Login);
      type('email', 'asha@example.com');
      type('password', 'secret123');
      submit();
      expect(el.querySelector('[role="alert"]')).toBeNull();
    });
  });

  describe('register', () => {
    it('flags mismatched passwords', () => {
      const { el, type, submit } = setup(Register);
      type('fullName', 'Asha Rao');
      type('email', 'asha@example.com');
      type('password', 'Passw0rdOne');
      type('confirmPassword', 'Passw0rdTwo');
      submit();
      expect(el.textContent).toContain('Passwords do not match');
    });

    it('requires a letter and a number in the password', () => {
      const { el, type, submit } = setup(Register);
      type('password', 'onlyletters');
      submit();
      expect(el.textContent).toContain('Include at least one number');
    });

    it('explains that recruiter accounts need approval', () => {
      const { fixture, el, select } = setup(Register);
      select('role', 'recruiter');
      fixture.detectChanges();
      expect(el.textContent).toContain('need admin approval');
    });

    it('does not offer an Admin role', () => {
      const { el } = setup(Register);
      const options = Array.from(el.querySelectorAll('option')).map((o) => o.textContent?.trim());
      expect(options).toEqual(['Student', 'Recruiter']);
    });
  });

  describe('honest submit behaviour', () => {
    it('login: a valid form calls the auth API and shows its message, never a fake success', () => {
      let called = false;
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        providers: testProviders({
          provide: AuthApi,
          useValue: {
            signIn: () => {
              called = true;
              return throwError(() => new ServiceUnavailableError('Sign-in needs the backend.'));
            },
          },
        }),
      });
      const { type, submit } = setup(Login);
      type('email', 'asha@example.com');
      type('password', 'secret123');
      submit();
      expect(called).toBe(true);
      const toasts = TestBed.inject(ToastService).toasts();
      expect(toasts.map((t) => t.message)).toContain('Sign-in needs the backend.');
      expect(toasts.every((t) => t.kind !== 'success')).toBe(true);
    });

    it('register: with the mock API the user is told the backend is required', () => {
      const { type, submit } = setup(Register);
      type('fullName', 'Asha Rao');
      type('email', 'asha@example.com');
      type('password', 'Passw0rd1');
      type('confirmPassword', 'Passw0rd1');
      submit();
      const toasts = TestBed.inject(ToastService).toasts();
      expect(toasts[0].message).toMatch(/needs the backend/);
      expect(toasts[0].kind).toBe('info');
    });

    it('demo role buttons are labelled as a preview', () => {
      const { el } = setup(Login);
      expect(el.textContent).toContain('Preview the app (demo mode)');
      expect(el.textContent).toContain('No account is created');
    });
  });
});
