import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Icon } from '../../ui/icon';
import { Progress } from '../../ui/progress';

@Component({
  selector: 'app-landing',
  imports: [RouterLink, Icon, Progress],
  template: `
    <section class="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 lg:grid-cols-2 lg:py-24">
      <div>
        <p class="text-sm font-medium text-brand-600">Gamified learning · AI career guidance · Campus placements</p>
        <h1 class="mt-3 text-4xl font-semibold tracking-tight text-slate-900 sm:text-5xl">Learn the skills. Prove them. Get placed.</h1>
        <p class="mt-4 max-w-xl text-lg text-slate-600">
          CampusQuest AI connects what students learn to the roles they apply for, so every quiz and challenge moves them closer to a placement.
        </p>
        <div class="mt-8 flex flex-wrap gap-3">
          <a routerLink="/register" class="btn btn-primary px-5 py-3">Create your account</a>
          <a routerLink="/features" class="btn btn-secondary px-5 py-3">See features</a>
        </div>
      </div>

      <div aria-label="Product preview (sample data)" class="card space-y-4 p-6">
        <p class="text-xs font-medium uppercase tracking-wide text-slate-400">Preview · sample data</p>
        <div class="flex items-end justify-between">
          <div><p class="text-sm text-slate-500">Total XP</p><p class="text-3xl font-semibold">2,650</p></div>
          <span class="rounded-full bg-amber-50 px-3 py-1 text-sm font-medium text-amber-700">Level 8 · Explorer</span>
        </div>
        <app-progress [value]="27" tone="xp" label="Progress to next level" />
        <div class="rounded-xl bg-brand-50 p-4">
          <p class="text-sm font-medium text-brand-700">Today's mission · +100 XP</p>
          <p class="mt-1 text-sm text-slate-700">Complete a SQL joins challenge and score at least 80%.</p>
        </div>
      </div>
    </section>

    <section class="bg-slate-50 py-16">
      <div class="mx-auto max-w-6xl px-4">
        <h2 class="text-2xl font-semibold tracking-tight">How it works</h2>
        <ol class="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          @for (s of steps; track s.title; let i = $index) {
            <li class="card h-full">
              <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><app-icon [name]="s.icon" /></span>
              <p class="mt-3 text-xs text-slate-400">Step {{ i + 1 }}</p>
              <h3 class="font-semibold">{{ s.title }}</h3>
              <p class="mt-1 text-sm text-slate-600">{{ s.text }}</p>
            </li>
          }
        </ol>
      </div>
    </section>

    <section class="mx-auto grid max-w-6xl gap-6 px-4 py-16 md:grid-cols-2">
      <div class="card">
        <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600"><app-icon name="UserCheck" /></span>
        <h2 class="mt-3 text-lg font-semibold">For students</h2>
        <p class="mt-2 text-slate-600">Know exactly what to do next, build a skill profile backed by evidence, and apply with confidence.</p>
      </div>
      <div class="card">
        <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><app-icon name="Briefcase" /></span>
        <h2 class="mt-3 text-lg font-semibold">For recruiters</h2>
        <p class="mt-2 text-slate-600">Post roles with clear eligibility, review candidates with skill evidence, and use matching as decision support, never as an automatic decision.</p>
      </div>
    </section>
  `,
})
export class Landing {
  protected readonly steps = [
    { icon: 'BookOpen', title: 'Learn', text: 'Structured courses and learning paths.' },
    { icon: 'ClipboardCheck', title: 'Assess', text: 'Quizzes that build evidence-backed skills.' },
    { icon: 'Trophy', title: 'Earn XP', text: 'Levels, badges, streaks and missions.' },
    { icon: 'Sparkles', title: 'Get guidance', text: 'AI resume analysis and a personal roadmap.' },
    { icon: 'Briefcase', title: 'Apply', text: 'Campus jobs with clear eligibility and tracking.' },
  ];
}
