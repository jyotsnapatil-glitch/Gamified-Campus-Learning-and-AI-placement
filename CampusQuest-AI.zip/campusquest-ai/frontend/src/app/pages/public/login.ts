import { Component, inject, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { ROLES, ROLE_HOME, ROLE_LABEL, Role } from '../../core/roles';
import { ToastService } from '../../core/toast.service';
import { AuthApi } from '../../services/contracts';
import { emailFormat } from './validators';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="mx-auto max-w-md px-4 py-16">
      <div class="card p-6">
        <h1 class="text-xl font-semibold">Log in</h1>
        <form [formGroup]="form" (ngSubmit)="submit()" novalidate class="mt-4 space-y-4">
          <div>
            <label for="email" class="field-label">Email</label>
            <input id="email" type="email" autocomplete="email" formControlName="email" class="field-input"
                   [class.invalid]="showError('email')" [attr.aria-invalid]="showError('email') ? true : null" aria-describedby="email-error" />
            @if (emailError(); as msg) { <p id="email-error" role="alert" class="field-error">{{ msg }}</p> }
          </div>
          <div>
            <label for="password" class="field-label">Password</label>
            <input id="password" type="password" autocomplete="current-password" formControlName="password" class="field-input"
                   [class.invalid]="showError('password')" [attr.aria-invalid]="showError('password') ? true : null" aria-describedby="password-error" />
            @if (passwordError(); as msg) { <p id="password-error" role="alert" class="field-error">{{ msg }}</p> }
          </div>
          <button type="submit" class="btn btn-primary w-full">Log in</button>
        </form>
        <p class="mt-3 text-sm"><a routerLink="/forgot-password" class="text-brand-600 hover:underline">Forgot your password?</a></p>

        <div class="mt-6 border-t border-slate-100 pt-4">
          <p class="text-sm font-medium">Preview the app (demo mode)</p>
          <p class="mt-1 text-xs text-slate-500">Sample data only. No account is created.</p>
          <div class="mt-3 grid grid-cols-3 gap-2">
            @for (r of roles; track r) {
              <button type="button" class="btn btn-secondary" (click)="demo(r)">{{ labels[r] }}</button>
            }
          </div>
        </div>
        <p class="mt-4 text-sm text-slate-600">New here? <a routerLink="/register" class="text-brand-600 hover:underline">Create an account</a></p>
      </div>
    </div>
  `,
})
export class Login {
  private readonly fb = inject(NonNullableFormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly toast = inject(ToastService);
  private readonly authApi = inject(AuthApi);

  protected readonly roles = ROLES;
  protected readonly labels = ROLE_LABEL;
  private readonly submitted = signal(false);

  protected readonly form = this.fb.group({
    email: ['', [Validators.required, emailFormat]],
    password: ['', [Validators.required]],
  });

  protected showError(name: 'email' | 'password') {
    const c = this.form.controls[name];
    return c.invalid && (c.touched || this.submitted());
  }
  protected emailError() {
    if (!this.showError('email')) return null;
    return this.form.controls.email.hasError('required') ? 'Enter your email' : 'Enter a valid email address';
  }
  protected passwordError() {
    return this.showError('password') ? 'Enter your password' : null;
  }

  protected submit() {
    this.submitted.set(true);
    this.form.markAllAsTouched();
    if (this.form.invalid) return;
    this.authApi.signIn(this.form.getRawValue()).subscribe({
      next: () => void this.router.navigateByUrl('/'),
      error: (e: unknown) => this.toast.info(e instanceof Error ? e.message : 'Sign-in failed. Please try again.'),
    });
  }

  protected demo(role: Role) {
    this.auth.signIn(role);
    void this.router.navigateByUrl(ROLE_HOME[role]);
  }
}
