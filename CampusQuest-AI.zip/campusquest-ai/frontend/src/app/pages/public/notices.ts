import { Component, computed, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { ROLE_HOME } from '../../core/roles';

@Component({
  selector: 'app-unauthorized',
  imports: [RouterLink],
  template: `
    <div class="mx-auto max-w-md px-4 py-24 text-center">
      <h1 class="text-2xl font-semibold">You don't have access to this page</h1>
      <p class="mt-2 text-slate-600">Your role doesn't include this area. Switch roles from the account menu to preview other areas.</p>
      <a [routerLink]="backLink()" class="btn btn-primary mt-6">{{ auth.role() ? 'Back to your dashboard' : 'Back to home' }}</a>
    </div>
  `,
})
export class Unauthorized {
  protected readonly auth = inject(AuthService);
  protected readonly backLink = computed(() => {
    const r = this.auth.role();
    return r ? ROLE_HOME[r] : '/';
  });
}

@Component({
  selector: 'app-not-found',
  imports: [RouterLink],
  template: `
    <div class="mx-auto max-w-md px-4 py-24 text-center">
      <h1 class="text-2xl font-semibold">Page not found</h1>
      <p class="mt-2 text-slate-600">That address doesn't exist or has moved.</p>
      <a [routerLink]="backLink()" class="btn btn-primary mt-6">{{ auth.role() ? 'Back to your dashboard' : 'Back to home' }}</a>
    </div>
  `,
})
export class NotFound {
  protected readonly auth = inject(AuthService);
  protected readonly backLink = computed(() => {
    const r = this.auth.role();
    return r ? ROLE_HOME[r] : '/';
  });
}
