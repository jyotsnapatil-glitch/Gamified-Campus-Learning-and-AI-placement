import { Component, inject } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { ROLE_HOME } from '../../core/roles';
import { Icon } from '../../ui/icon';

@Component({
  selector: 'app-public-layout',
  imports: [RouterLink, RouterOutlet, Icon],
  template: `
    <div class="flex min-h-full flex-col bg-white">
      <header class="border-b border-slate-100">
        <div class="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <a routerLink="/" class="flex items-center gap-2 font-semibold">
            <span class="rounded-lg bg-brand-600 p-1.5 text-white"><app-icon name="Rocket" /></span>
            CampusQuest AI
          </a>
          <nav aria-label="Public" class="flex items-center gap-2">
            <a routerLink="/features" class="px-3 text-sm text-slate-600 hover:text-slate-900">Features</a>
            @if (auth.role(); as role) {
              <a [routerLink]="home[role]" class="btn btn-primary">Open app</a>
            } @else {
              <a routerLink="/login" class="btn btn-ghost">Log in</a>
              <a routerLink="/register" class="btn btn-primary">Get started</a>
            }
          </nav>
        </div>
      </header>
      <main class="flex-1"><router-outlet /></main>
      <footer class="border-t border-slate-100 bg-slate-50">
        <div class="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-6 text-sm text-slate-500">
          <p>CampusQuest AI · portfolio project</p>
          <p>Demo mode: sample data, no backend connected yet.</p>
        </div>
      </footer>
    </div>
  `,
})
export class PublicLayout {
  protected readonly auth = inject(AuthService);
  protected readonly home = ROLE_HOME;
}
