import { Component, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ToastService } from '../../core/toast.service';
import { AuthApi } from '../../services/contracts';
import { ALLOWED_SIGNUP_ROLES, emailFormat, hasLetter, hasNumber, passwordsMatch, trimmedMinLength } from './validators';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="mx-auto max-w-md px-4 py-16">
      <div class="card p-6">
        <h1 class="text-xl font-semibold">Create your account</h1>
        <form [formGroup]="form" (ngSubmit)="submit()" novalidate class="mt-4 space-y-4">
          <div>
            <label for="fullName" class="field-label">Full name</label>
            <input id="fullName" autocomplete="name" formControlName="fullName" class="field-input" [class.invalid]="show('fullName')" />
            @if (show('fullName')) { <p role="alert" class="field-error">Enter your full name</p> }
          </div>
          <div>
            <label for="email" class="field-label">Email</label>
            <input id="email" type="email" autocomplete="email" formControlName="email" class="field-input" [class.invalid]="show('email')" />
            @if (show('email')) {
              <p role="alert" class="field-error">{{ form.controls.email.hasError('required') ? 'Enter your email' : 'Enter a valid email address' }}</p>
            }
          </div>
          <div>
            <label for="role" class="field-label">I am a</label>
            <select id="role" formControlName="role" class="field-input">
              <option value="student">Student</option>
              <option value="recruiter">Recruiter</option>
            </select>
            @if (role() === 'recruiter') {
              <p class="mt-1 text-xs text-slate-500">Recruiter accounts need admin approval before you can post jobs.</p>
            }
          </div>
          <div>
            <label for="password" class="field-label">Password</label>
            <input id="password" type="password" autocomplete="new-password" formControlName="password" class="field-input" [class.invalid]="show('password')" />
            @if (passwordError(); as msg) { <p role="alert" class="field-error">{{ msg }}</p> }
          </div>
          <div>
            <label for="confirmPassword" class="field-label">Confirm password</label>
            <input id="confirmPassword" type="password" autocomplete="new-password" formControlName="confirmPassword" class="field-input" [class.invalid]="show('confirmPassword')" />
            @if (confirmError(); as msg) { <p role="alert" class="field-error">{{ msg }}</p> }
          </div>
          <button type="submit" class="btn btn-primary w-full">Create account</button>
        </form>
        <p class="mt-4 text-sm text-slate-600">Already registered? <a routerLink="/login" class="text-brand-600 hover:underline">Log in</a></p>
      </div>
    </div>
  `,
})
export class Register {
  private readonly fb = inject(NonNullableFormBuilder);
  private readonly toast = inject(ToastService);
  private readonly authApi = inject(AuthApi);
  private readonly submitted = signal(false);

  protected readonly form = this.fb.group(
    {
      fullName: ['', [trimmedMinLength(2)]],
      email: ['', [Validators.required, emailFormat]],
      role: this.fb.control<(typeof ALLOWED_SIGNUP_ROLES)[number]>('student', [
        (c) => (ALLOWED_SIGNUP_ROLES.includes(c.value) ? null : { role: true }),
      ]),
      password: ['', [Validators.minLength(8), hasLetter, hasNumber]],
      confirmPassword: ['', [Validators.required]],
    },
    { validators: [passwordsMatch] },
  );

  protected readonly role = toSignal(this.form.controls.role.valueChanges, { initialValue: 'student' as const });

  protected show(name: keyof typeof this.form.controls) {
    const c = this.form.controls[name];
    return c.invalid && (c.touched || this.submitted());
  }

  protected passwordError() {
    if (!this.show('password')) return null;
    const c = this.form.controls.password;
    if (c.hasError('minlength')) return 'Use at least 8 characters';
    if (c.hasError('noLetter')) return 'Include at least one letter';
    return 'Include at least one number';
  }

  protected confirmError() {
    if (!this.show('confirmPassword')) return null;
    const c = this.form.controls.confirmPassword;
    return c.hasError('required') ? 'Confirm your password' : 'Passwords do not match';
  }

  protected submit() {
    this.submitted.set(true);
    this.form.markAllAsTouched();
    this.form.updateValueAndValidity();
    if (this.form.invalid) return;
    const v = this.form.getRawValue();
    this.authApi.register({ fullName: v.fullName, email: v.email, role: v.role, password: v.password }).subscribe({
      next: () => this.toast.success('Account created. You can log in now.'),
      error: (e: unknown) => this.toast.info(e instanceof Error ? e.message : 'Registration failed. Please try again.'),
    });
  }
}
