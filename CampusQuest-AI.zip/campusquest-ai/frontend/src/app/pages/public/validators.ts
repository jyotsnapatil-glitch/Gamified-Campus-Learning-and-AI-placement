import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const emailFormat: ValidatorFn = (c: AbstractControl): ValidationErrors | null =>
  !c.value || EMAIL.test(String(c.value)) ? null : { emailFormat: true };

export const hasLetter: ValidatorFn = (c) => (/[A-Za-z]/.test(String(c.value ?? '')) ? null : { noLetter: true });
export const hasNumber: ValidatorFn = (c) => (/[0-9]/.test(String(c.value ?? '')) ? null : { noNumber: true });

export const trimmedMinLength = (min: number): ValidatorFn => (c) =>
  String(c.value ?? '').trim().length >= min ? null : { trimmedMinLength: { min } };

/** Group validator: sets a `mismatch` error on the confirm field when passwords differ. */
export const passwordsMatch: ValidatorFn = (group) => {
  const password = group.get('password')?.value;
  const confirm = group.get('confirmPassword');
  if (!confirm) return null;
  const mismatch = !!confirm.value && password !== confirm.value;
  const current = confirm.errors ?? {};
  if (mismatch) confirm.setErrors({ ...current, mismatch: true });
  else if ('mismatch' in current) {
    const { mismatch: _drop, ...rest } = current;
    confirm.setErrors(Object.keys(rest).length ? rest : null);
  }
  return null;
};

export const ALLOWED_SIGNUP_ROLES = ['student', 'recruiter'] as const;
