import { of, throwError } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { fullDashboard } from '../../mocks/fixtures';
import { DashboardService } from '../../services/contracts';
import { openApp } from '../../testing/open-app';

const links = (root: HTMLElement) => Array.from(root.querySelectorAll('a'));

describe('student dashboard', () => {
  beforeEach(() => sessionStorage.clear());

  it('shows a loading skeleton, then the progress metrics', async () => {
    const { root, text, waitForText } = await openApp('/student/dashboard', 'student');
    expect(root.querySelector('[aria-label="Loading dashboard"]')).not.toBeNull();
    await waitForText('Total XP');
    expect(text()).toContain('2,650');
    expect(text()).toContain('Level 8 · Explorer');
    expect(text()).toContain('7 days');
    expect(text()).toContain('5/8');
    expect(text()).toContain('Demo data');
  });

  it('shows the level ring and a next-step call to action in the hero', async () => {
    const { root, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText('Total XP');
    expect(root.querySelector('[role="img"][aria-label*="Level 8, 27% of the way to level 9"]')).not.toBeNull();
    const cta = links(root).find((a) => a.textContent?.includes('Continue SQL Mastery'));
    expect(cta?.getAttribute('href')).toBe('/student/learning');
  });

  it('shows learning cards, recommended paths and the weekly XP chart', async () => {
    const { root, text, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText('Total XP');
    expect(text()).toContain('SQL Mastery');
    expect(text()).toContain('ASP.NET Core Web API');
    expect(text()).toContain('.NET Backend Developer');
    expect(links(root).filter((a) => a.textContent?.trim() === 'Resume')).toHaveLength(2);
    expect(root.querySelector('[role="img"][aria-label*="XP earned this week: Mon 120 XP"]')).not.toBeNull();
  });

  it('shows the daily mission with a working link', async () => {
    const { root, text, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText("Today's mission");
    const link = links(root).find((a) => a.textContent?.trim() === 'View mission');
    expect(link?.getAttribute('href')).toBe('/student/missions');
    expect(text()).toContain('+100 XP');
  });

  it('shows an empty state for a new student', async () => {
    const { root, waitForText } = await openApp('/student/dashboard?demo=empty', 'student');
    await waitForText('Start your first quest');
    const link = links(root).find((a) => a.textContent?.includes('Take baseline assessment'));
    expect(link?.getAttribute('href')).toBe('/student/skills');
  });

  it('shows an error state with a retry action', async () => {
    const { root, waitForText } = await openApp('/student/dashboard?demo=error', 'student');
    await waitForText('could not be reached');
    expect(root.querySelector('[role="alert"]')?.textContent).toContain('Try again');
  });

  it('retries the request when Try again is clicked', async () => {
    let calls = 0;
    const fake: DashboardService = {
      getDashboard: () => {
        calls += 1;
        return calls === 1 ? throwError(() => new Error('Temporary failure')) : of(fullDashboard);
      },
    };
    const { root, waitForText } = await openApp('/student/dashboard', 'student', { provide: DashboardService, useValue: fake });
    await waitForText('Temporary failure');
    Array.from(root.querySelectorAll('button')).find((b) => b.textContent?.trim() === 'Try again')!.click();
    await waitForText('Total XP');
    expect(calls).toBe(2);
  });

  it('renders whatever the service returns, so the real API can replace the mock', async () => {
    const fake: DashboardService = { getDashboard: () => of({ ...fullDashboard, firstName: 'Zed', totalXp: 50 }) };
    const { waitForText } = await openApp('/student/dashboard', 'student', { provide: DashboardService, useValue: fake });
    await waitForText('Zed');
    await waitForText('Level 2 · Newcomer');
  });
});

describe('app shell', () => {
  beforeEach(() => sessionStorage.clear());

  it('collapses and expands the sidebar', async () => {
    const { root, text, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText('Total XP');
    const label = () =>
      Array.from(root.querySelectorAll('nav[aria-label="Main navigation"] span')).find((s) => s.textContent?.trim() === 'Learning')!;
    expect(label().className).not.toContain('sr-only');
    root.querySelector<HTMLButtonElement>('button[aria-label="Collapse or expand sidebar"]')!.click();
    await vi.waitFor(() => {
      text();
      expect(label().className).toContain('sr-only');
    });
  });

  it('finds pages through search', async () => {
    const { harness, root, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText('Total XP');
    const input = root.querySelector<HTMLInputElement>('input[aria-label="Search pages"]')!;
    input.value = 'jobs';
    input.dispatchEvent(new Event('input'));
    harness.detectChanges();
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
    await waitForText("Jobs isn't built yet");
  });

  it('shows unread notifications and marks them read through the service', async () => {
    const { root, text, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText('Total XP');
    const bell = () => root.querySelector<HTMLButtonElement>('button[aria-label^="Notifications"]')!;
    await vi.waitFor(() => {
      text();
      expect(bell().getAttribute('aria-label')).toBe('Notifications, 2 unread');
    });
    bell().click();
    await waitForText('Mark all read');
    Array.from(root.querySelectorAll('button')).find((b) => b.textContent?.trim() === 'Mark all read')!.click();
    await vi.waitFor(() => {
      text();
      expect(bell().getAttribute('aria-label')).toBe('Notifications, 0 unread');
    });
  });

  it('opens a notification and goes to the linked page', async () => {
    const { root, text, waitForText } = await openApp('/student/dashboard', 'student');
    await waitForText('Total XP');
    const bell = () => root.querySelector<HTMLButtonElement>('button[aria-label^="Notifications"]')!;
    await vi.waitFor(() => {
      text();
      expect(bell().getAttribute('aria-label')).toBe('Notifications, 2 unread');
    });
    bell().click();
    await waitForText('New job: .NET Intern');
    Array.from(root.querySelectorAll('button')).find((b) => b.textContent?.includes('New job: .NET Intern'))!.click();
    await waitForText("Jobs isn't built yet");
  });
});
