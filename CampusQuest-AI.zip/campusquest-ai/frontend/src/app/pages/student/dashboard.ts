import { DecimalPipe } from '@angular/common';
import { Component, DestroyRef, computed, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DashboardService } from '../../services/contracts';
import { CourseLevel, DashboardData } from '../../services/models';
import { LevelProgress, levelProgress } from '../../core/xp';
import { Icon } from '../../ui/icon';
import { Progress } from '../../ui/progress';
import { EmptyState, ErrorState } from '../../ui/states';

const LEVEL_BADGE: Record<CourseLevel, string> = {
  Beginner: 'badge-success',
  Intermediate: 'badge-brand',
  Advanced: 'badge-warning',
};

@Component({
  selector: 'app-xp-ring',
  template: `
    <div class="relative h-36 w-36 shrink-0" role="img" [attr.aria-label]="label()">
      <svg viewBox="0 0 128 128" class="h-full w-full -rotate-90" aria-hidden="true">
        <circle cx="64" cy="64" r="54" fill="none" stroke="rgba(255,255,255,0.12)" stroke-width="10" />
        <circle cx="64" cy="64" r="54" fill="none" stroke="#f59e0b" stroke-width="10" stroke-linecap="round"
                [attr.stroke-dasharray]="circumference" [attr.stroke-dashoffset]="offset()"
                class="transition-[stroke-dashoffset] duration-700" />
      </svg>
      <div class="absolute inset-0 flex flex-col items-center justify-center">
        <span class="text-xs uppercase tracking-wide text-slate-300">Level</span>
        <span class="text-4xl font-semibold leading-none">{{ progress().level }}</span>
        <span class="mt-1 text-xs text-amber-300">{{ progress().title }}</span>
      </div>
    </div>
  `,
})
export class XpRing {
  readonly progress = input.required<LevelProgress>();
  protected readonly circumference = 2 * Math.PI * 54;
  protected readonly offset = computed(() => this.circumference * (1 - this.progress().percent / 100));
  protected readonly label = computed(
    () => `Level ${this.progress().level}, ${this.progress().percent}% of the way to level ${this.progress().level + 1}`,
  );
}

@Component({
  selector: 'app-weekly-xp-chart',
  template: `
    <div class="card">
      <div class="flex items-baseline justify-between">
        <h2 class="font-semibold">XP this week</h2>
        <p class="text-sm text-slate-500"><span class="font-semibold text-amber-700">{{ total() }}</span> XP total</p>
      </div>
      <div role="img" [attr.aria-label]="'XP earned this week: ' + summary()" class="mt-4 flex h-32 items-end gap-2">
        @for (d of data(); track d.day) {
          <div class="flex h-full flex-1 flex-col items-center justify-end gap-1" [attr.title]="d.day + ': ' + d.xp + ' XP'">
            <div class="w-full rounded-t-md transition-colors"
                 [class]="d.xp > 0 ? 'bg-amber-400 hover:bg-amber-500' : 'bg-slate-100'"
                 [style.height.%]="height(d.xp)"></div>
            <span class="text-xs text-slate-500">{{ d.day }}</span>
          </div>
        }
      </div>
    </div>
  `,
})
export class WeeklyXpChart {
  readonly data = input.required<DashboardData['weeklyXp']>();
  private readonly max = computed(() => Math.max(...this.data().map((d) => d.xp), 1));
  protected readonly total = computed(() => this.data().reduce((sum, d) => sum + d.xp, 0));
  protected readonly summary = computed(() => this.data().map((d) => `${d.day} ${d.xp} XP`).join(', '));
  protected height(xp: number) {
    return Math.max((xp / this.max()) * 100, xp > 0 ? 6 : 3);
  }
}

@Component({
  selector: 'app-metric-card',
  imports: [Icon],
  template: `
    <div class="card transition-shadow hover:shadow-md">
      <div class="flex items-center gap-2 text-sm text-slate-500">
        <span class="rounded-lg p-1.5" [class]="tone()"><app-icon [name]="icon()" [size]="16" /></span>
        {{ label() }}
      </div>
      <p class="mt-3 text-3xl font-semibold tracking-tight">{{ value() }}</p>
      <p class="mt-1 text-sm text-slate-500">{{ hint() }}</p>
      <div class="mt-3 empty:hidden"><ng-content /></div>
    </div>
  `,
})
export class MetricCard {
  readonly icon = input.required<string>();
  readonly label = input.required<string>();
  readonly value = input.required<string>();
  readonly hint = input.required<string>();
  readonly tone = input.required<string>();
}

function greeting(date: Date) {
  const h = date.getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}

@Component({
  selector: 'app-student-dashboard',
  imports: [RouterLink, DecimalPipe, Icon, Progress, EmptyState, ErrorState, MetricCard, XpRing, WeeklyXpChart],
  template: `
    @switch (status()) {
      @case ('loading') {
        <div aria-busy="true" aria-label="Loading dashboard" class="space-y-6">
          <div aria-hidden="true" class="h-48 animate-pulse rounded-lg bg-slate-200/70"></div>
          <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            @for (i of [0, 1, 2, 3]; track i) { <div aria-hidden="true" class="h-32 animate-pulse rounded-lg bg-slate-200/70"></div> }
          </div>
          <div class="grid gap-4 lg:grid-cols-3">
            <div aria-hidden="true" class="h-64 animate-pulse rounded-lg bg-slate-200/70 lg:col-span-2"></div>
            <div aria-hidden="true" class="h-64 animate-pulse rounded-lg bg-slate-200/70"></div>
          </div>
        </div>
      }
      @case ('error') {
        <app-error-state [message]="errorMessage()" (retry)="load()" />
      }
      @case ('ready') {
        @if (data(); as d) {
          @if (d.isNewStudent) {
            <div class="space-y-6">
              <h1 class="text-2xl font-semibold tracking-tight">{{ greet }}, {{ d.firstName }}</h1>
              <app-empty-state
                title="Start your first quest"
                description="Take a baseline assessment so we can build your skill profile, recommend learning paths, and start earning XP."
              >
                <a routerLink="/student/skills" class="btn btn-primary">Take baseline assessment</a>
              </app-empty-state>
            </div>
          } @else if (level(); as lp) {
            <div class="space-y-6">
              <div role="note" class="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                Demo data: sample content, not connected to a backend yet.
              </div>

              <section class="rounded-2xl bg-navy-900 p-6 text-white shadow-sm sm:p-8">
                <div class="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                  <div class="max-w-xl">
                    <p class="text-xs font-medium tracking-wide text-slate-300">STUDENT WORKSPACE · {{ dateLabel }}</p>
                    <h1 class="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">{{ greet }}, {{ d.firstName }}</h1>
                    <p class="mt-2 text-slate-300">
                      You're {{ lp.xpToNext | number }} XP away from level {{ lp.level + 1 }}.
                      @if (d.continueLearning[0]; as first) { Pick up where you left off in {{ first.title }}. }
                    </p>
                    <div class="mt-5 flex flex-wrap gap-3">
                      <a routerLink="/student/learning" class="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-sm font-medium text-navy-900 transition-colors hover:bg-slate-100">
                        @if (d.continueLearning[0]; as first) { Continue {{ first.title }} } @else { Browse courses }
                        <app-icon name="ArrowRight" [size]="16" />
                      </a>
                      <a routerLink="/student/missions" class="inline-flex items-center gap-2 rounded-lg border border-white/30 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-white/10">
                        View today's mission
                      </a>
                    </div>
                  </div>
                  <app-xp-ring [progress]="lp" />
                </div>
              </section>

              <section aria-label="Your progress" class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <app-metric-card icon="Zap" tone="bg-amber-50 text-amber-600" label="Total XP"
                                 [value]="(d.totalXp | number)!" [hint]="'Level ' + lp.level + ' · ' + lp.title">
                  <app-progress [value]="lp.percent" tone="xp" label="Progress to next level" />
                  <p class="mt-1 text-xs text-slate-500">{{ lp.xpToNext | number }} XP to level {{ lp.level + 1 }}</p>
                </app-metric-card>
                <app-metric-card icon="Flame" tone="bg-orange-50 text-orange-600" label="Daily streak"
                                 [value]="d.streakDays + (d.streakDays === 1 ? ' day' : ' days')"
                                 [hint]="d.streakDays > 0 ? 'Keep your momentum' : 'Learn today to start a streak'" />
                <app-metric-card icon="Target" tone="bg-brand-50 text-brand-600" label="Learning progress"
                                 [value]="d.learningProgressPercent + '%'" hint="Across enrolled courses">
                  <app-progress [value]="d.learningProgressPercent" label="Learning progress" />
                </app-metric-card>
                <app-metric-card icon="Trophy" tone="bg-emerald-50 text-emerald-600" label="Skills assessed"
                                 [value]="d.skillsAssessed + '/' + d.skillsTotal"
                                 [hint]="d.skillsTotal - d.skillsAssessed + ' assessments remaining'" />
              </section>

              <div class="grid gap-4 lg:grid-cols-3">
                <div class="space-y-4 lg:col-span-2">
                  <div class="card border-brand-100 bg-brand-50/50">
                    <div class="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <p class="text-sm font-medium text-brand-700">Today's mission</p>
                        <h2 class="text-lg font-semibold">{{ d.mission.title }}</h2>
                      </div>
                      <span class="badge badge-xp">+{{ d.mission.xp }} XP</span>
                    </div>
                    <p class="mt-2 text-slate-700">{{ d.mission.description }}</p>
                    <div class="mt-4 flex flex-wrap items-center gap-4">
                      <div class="min-w-40 flex-1">
                        <app-progress [value]="(d.mission.tasksDone / d.mission.tasksTotal) * 100" tone="success" label="Mission tasks completed" />
                        <p class="mt-1 text-xs text-slate-500">{{ d.mission.tasksDone }} of {{ d.mission.tasksTotal }} tasks completed</p>
                      </div>
                      <a routerLink="/student/missions" class="btn btn-primary">View mission</a>
                    </div>
                  </div>

                  <section aria-labelledby="continue-heading">
                    <div class="mb-3 flex items-center justify-between">
                      <h2 id="continue-heading" class="font-semibold">Continue learning</h2>
                      <a routerLink="/student/learning" class="text-sm text-brand-600 hover:underline">All courses</a>
                    </div>
                    <div class="grid gap-4 sm:grid-cols-2">
                      @for (c of d.continueLearning; track c.id) {
                        <div class="card flex flex-col transition-all hover:-translate-y-0.5 hover:shadow-md">
                          <div class="flex items-start justify-between">
                            <span class="rounded-xl bg-brand-50 p-2.5 text-brand-600"><app-icon name="BookOpen" [size]="20" /></span>
                            <span class="badge" [class]="levelBadge[c.level]">{{ c.level }}</span>
                          </div>
                          <h3 class="mt-3 font-semibold">{{ c.title }}</h3>
                          <p class="text-sm text-slate-500">{{ c.moduleLabel }}</p>
                          <div class="mt-3 flex items-center gap-3">
                            <div class="flex-1"><app-progress [value]="c.percent" [label]="c.title + ' progress'" /></div>
                            <span class="text-sm font-medium text-slate-600">{{ c.percent }}%</span>
                          </div>
                          <a routerLink="/student/learning" class="btn btn-secondary mt-4 w-full">Resume</a>
                        </div>
                      }
                    </div>
                  </section>

                  <section aria-labelledby="paths-heading">
                    <div class="mb-3 flex items-center justify-between">
                      <h2 id="paths-heading" class="font-semibold">Recommended learning paths</h2>
                      <a routerLink="/student/roadmap" class="text-sm text-brand-600 hover:underline">My roadmap</a>
                    </div>
                    <div class="grid gap-4 sm:grid-cols-3">
                      @for (p of d.recommendedPaths; track p.id) {
                        <div class="card flex flex-col transition-all hover:-translate-y-0.5 hover:shadow-md">
                          <span class="badge self-start" [class]="levelBadge[p.level]">{{ p.level }}</span>
                          <h3 class="mt-3 font-semibold">{{ p.title }}</h3>
                          <p class="mt-1 flex-1 text-sm text-slate-600">{{ p.description }}</p>
                          <p class="mt-3 flex items-center gap-1 text-xs text-slate-500">
                            <app-icon name="Clock" [size]="14" /> {{ p.lessons }} lessons · {{ p.hours }} h
                          </p>
                          <a routerLink="/student/learning" class="mt-3 inline-flex items-center gap-1 text-sm font-medium text-brand-600 hover:underline">
                            View path <app-icon name="ArrowRight" [size]="14" />
                          </a>
                        </div>
                      }
                    </div>
                  </section>

                  <app-weekly-xp-chart [data]="d.weeklyXp" />
                </div>

                <div class="space-y-4">
                  <div class="card">
                    <div class="flex items-center gap-2">
                      <span class="rounded-lg bg-brand-50 p-1.5 text-brand-600"><app-icon name="Sparkles" [size]="16" /></span>
                      <h2 class="font-semibold">AI career insight</h2>
                    </div>
                    <p class="mt-3 text-slate-700">{{ d.insight.text }}</p>
                    <p class="mt-2 text-xs text-slate-500">Illustrative recommendation. Live insights will come from your assessment history.</p>
                    <a routerLink="/student/career-coach" class="btn btn-secondary mt-3">Explore recommendation</a>
                  </div>

                  <div class="card">
                    <div class="flex items-center justify-between">
                      <h2 class="font-semibold">Weekly leaderboard</h2>
                      <a routerLink="/student/leaderboard" class="text-sm text-brand-600 hover:underline">Full board</a>
                    </div>
                    <ol class="mt-3 space-y-1">
                      @for (r of d.leaderboard; track r.rank) {
                        <li class="flex items-center gap-3 rounded-lg px-2 py-2 text-sm" [class]="r.isYou ? 'bg-brand-50 font-medium' : 'hover:bg-slate-50'">
                          <span class="w-5 text-slate-500">{{ r.rank }}</span>
                          <span class="flex-1">{{ r.name }}</span>
                          <span class="text-amber-700">{{ r.xp }} XP</span>
                        </li>
                      }
                    </ol>
                    <p class="mt-2 text-xs text-slate-500">Weekly XP, demo values.</p>
                  </div>

                  <div class="card">
                    <div class="flex items-center justify-between">
                      <h2 class="font-semibold">Recent achievements</h2>
                      <a routerLink="/student/achievements" class="text-sm text-brand-600 hover:underline">All badges</a>
                    </div>
                    <ul class="mt-3 space-y-3">
                      @for (a of d.achievements; track a.id) {
                        <li class="flex items-start gap-3">
                          <span class="rounded-lg bg-amber-50 p-1.5 text-amber-600"><app-icon name="Trophy" [size]="16" /></span>
                          <div>
                            <p class="text-sm font-medium">{{ a.name }}</p>
                            <p class="text-xs text-slate-500">{{ a.description }}</p>
                          </div>
                        </li>
                      }
                    </ul>
                  </div>

                  <div class="card">
                    <div class="flex items-center justify-between">
                      <h2 class="font-semibold">Recommended campus jobs</h2>
                      <a routerLink="/student/jobs" class="text-sm text-brand-600 hover:underline">All jobs</a>
                    </div>
                    <ul class="mt-3 divide-y divide-slate-100">
                      @for (j of d.recommendedJobs; track j.id) {
                        <li class="flex items-center gap-3 py-3">
                          <span class="rounded-lg bg-slate-100 p-2 text-slate-600"><app-icon name="Briefcase" [size]="16" /></span>
                          <div>
                            <p class="text-sm font-medium">{{ j.title }}</p>
                            <p class="text-xs text-slate-500">{{ j.company }} · {{ j.location }}</p>
                          </div>
                        </li>
                      }
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          }
        }
      }
    }
  `,
})
export class StudentDashboard {
  private readonly api = inject(DashboardService);
  private readonly route = inject(ActivatedRoute);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly status = signal<'loading' | 'ready' | 'error'>('loading');
  protected readonly data = signal<DashboardData | null>(null);
  protected readonly errorMessage = signal('');
  protected readonly level = computed(() => {
    const d = this.data();
    return d ? levelProgress(d.totalXp) : null;
  });

  protected readonly levelBadge = LEVEL_BADGE;
  private readonly now = new Date();
  protected readonly greet = greeting(this.now);
  protected readonly dateLabel = this.now
    .toLocaleDateString('en-IN', { weekday: 'long', month: 'long', day: 'numeric' })
    .toUpperCase();

  constructor() {
    this.load();
  }

  protected load() {
    this.status.set('loading');
    const scenario = this.route.snapshot.queryParamMap.get('demo');
    this.api
      .getDashboard({ scenario })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (d) => {
          this.data.set(d);
          this.status.set('ready');
        },
        error: (e: unknown) => {
          this.errorMessage.set(e instanceof Error ? e.message : 'Something went wrong.');
          this.status.set('error');
        },
      });
  }
}
