import { Observable } from 'rxjs';
import { AppNotification, DashboardData, DashboardQuery, RegisterInput, SignInCredentials } from './models';

/**
 * Service contracts. Each one is an abstract class so it works as both the interface and the DI token.
 * Pages inject these and never import a mock. Phase 2 provides mock implementations (src/app/mocks);
 * Phase 3 provides HTTP implementations that call the ASP.NET Core API, with one change in app.config.ts.
 */
export abstract class DashboardService {
  abstract getDashboard(query?: DashboardQuery): Observable<DashboardData>;
}

export abstract class NotificationService {
  abstract list(): Observable<AppNotification[]>;
  abstract markRead(id: number): Observable<void>;
  abstract markAllRead(): Observable<void>;
}

export abstract class AuthApi {
  abstract signIn(credentials: SignInCredentials): Observable<void>;
  abstract register(input: RegisterInput): Observable<void>;
  abstract requestPasswordReset(email: string): Observable<void>;
}

/** Raised when an action needs a backend that is not connected yet. The UI shows the message as-is. */
export class ServiceUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ServiceUnavailableError';
  }
}
