/**
 * Data shapes shared by the UI and the data layer. Phase 3 HTTP services return exactly these shapes,
 * so the pages do not change when the mocks are replaced.
 */

export type CourseLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export interface CourseProgress {
  id: number;
  title: string;
  moduleLabel: string;
  level: CourseLevel;
  percent: number;
}

export interface LearningPath {
  id: number;
  title: string;
  description: string;
  level: CourseLevel;
  lessons: number;
  hours: number;
}

export interface DashboardData {
  isNewStudent: boolean;
  firstName: string;
  totalXp: number;
  streakDays: number;
  learningProgressPercent: number;
  skillsAssessed: number;
  skillsTotal: number;
  mission: { title: string; description: string; xp: number; tasksDone: number; tasksTotal: number };
  insight: { text: string };
  continueLearning: CourseProgress[];
  recommendedPaths: LearningPath[];
  weeklyXp: { day: string; xp: number }[];
  leaderboard: { rank: number; name: string; xp: number; isYou: boolean }[];
  achievements: { id: number; name: string; description: string }[];
  recommendedJobs: { id: number; title: string; company: string; location: string }[];
}

export interface DashboardQuery {
  /** Only the mock service reads this (to preview empty/error/loading states). A real API ignores it. */
  scenario?: string | null;
}

export interface AppNotification {
  id: number;
  title: string;
  to: string;
  read: boolean;
}

export interface SignInCredentials {
  email: string;
  password: string;
}

export interface RegisterInput {
  fullName: string;
  email: string;
  role: 'student' | 'recruiter';
  password: string;
}
