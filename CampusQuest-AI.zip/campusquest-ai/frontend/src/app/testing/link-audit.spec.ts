import { beforeEach, describe, expect, it } from 'vitest';
import { ALL_NAV_ITEMS } from '../core/nav-config';
import { Role } from '../core/roles';
import { openApp } from './open-app';

const PUBLIC_PATHS = ['/', '/features', '/login', '/register', '/forgot-password', '/unauthorized', '/not-found'];
const KNOWN = new Set([...PUBLIC_PATHS, ...ALL_NAV_ITEMS.map((n) => n.to)]);

function internalLinks(root: HTMLElement) {
  return Array.from(root.querySelectorAll('a[href]'))
    .map((a) => a.getAttribute('href')!)
    .filter((href) => href.startsWith('/'));
}

/** Every visible link must point at a route that exists, so there are no dead links. */
describe('link audit', () => {
  beforeEach(() => sessionStorage.clear());

  it.each(['/', '/features', '/login', '/register', '/forgot-password'])('public page %s only links to real routes', async (path) => {
    const { root, waitForText } = await openApp(path, null);
    await waitForText('CampusQuest AI');
    const links = internalLinks(root);
    expect(links.length).toBeGreaterThan(1);
    for (const href of links) expect(KNOWN.has(href), `${path} -> ${href}`).toBe(true);
  });

  const pages: [Role, string, string][] = [
    ['student', '/student/dashboard', 'Total XP'],
    ['student', '/student/learning', "Learning isn't built yet"],
    ['recruiter', '/recruiter/dashboard', "isn't built yet"],
    ['admin', '/admin/dashboard', "isn't built yet"],
  ];
  it.each(pages)('%s page %s only links to real routes', async (role, path, marker) => {
    const { root, waitForText } = await openApp(path, role);
    await waitForText(marker);
    const links = internalLinks(root);
    expect(links.length).toBeGreaterThan(3);
    for (const href of links) expect(KNOWN.has(href), `${path} -> ${href}`).toBe(true);
  });
});
