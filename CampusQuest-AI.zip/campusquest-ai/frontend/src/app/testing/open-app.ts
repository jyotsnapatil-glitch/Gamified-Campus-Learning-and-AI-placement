import { Provider } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { RouterTestingHarness } from '@angular/router/testing';
import { expect, vi } from 'vitest';
import { AuthService } from '../core/auth.service';
import { Role } from '../core/roles';
import { testProviders } from './test-providers';

/** Boots the real app at a URL (optionally signed in as a demo role) and returns small DOM helpers. */
export async function openApp(url: string, role: Role | null = null, ...overrides: Provider[]) {
  sessionStorage.clear();
  TestBed.configureTestingModule({ providers: testProviders(...overrides) });
  if (role) TestBed.inject(AuthService).signIn(role);
  const harness = await RouterTestingHarness.create();
  await harness.navigateByUrl(url);
  const root = harness.fixture.nativeElement as HTMLElement;
  const text = () => {
    harness.detectChanges();
    return root.textContent ?? '';
  };
  const waitForText = (expected: string) => vi.waitFor(() => expect(text()).toContain(expected));
  return { harness, root, text, waitForText };
}
