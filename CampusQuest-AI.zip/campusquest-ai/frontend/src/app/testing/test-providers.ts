import { EnvironmentProviders, Provider } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from '../app.routes';
import { MOCK_LATENCY_MS, provideMockServices } from '../mocks/mock-services';

/** Providers for tests: real routes, mock services, no artificial latency. Overrides win. */
export function testProviders(...overrides: Provider[]): (Provider | EnvironmentProviders)[] {
  return [provideRouter(routes), ...provideMockServices(), { provide: MOCK_LATENCY_MS, useValue: 0 }, ...overrides];
}
