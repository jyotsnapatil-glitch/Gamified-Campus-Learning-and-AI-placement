import { Component, ElementRef, effect, inject, input } from '@angular/core';
import { createElement } from 'lucide';
import { ICONS, IconName } from './icons';

@Component({
  selector: 'app-icon',
  template: '',
  host: { 'aria-hidden': 'true', class: 'inline-flex shrink-0' },
})
export class Icon {
  readonly name = input.required<IconName | string>();
  readonly size = input(18);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);

  constructor() {
    effect(() => {
      const node = (ICONS as Record<string, Parameters<typeof createElement>[0]>)[this.name()];
      const el = this.host.nativeElement;
      el.replaceChildren();
      if (node) el.appendChild(createElement(node, { width: this.size(), height: this.size() }));
    });
  }
}
