import {
  ArrowRight, Bell, BookOpen, Briefcase, CalendarDays, ChartColumn, Check, ChevronDown, ChevronRight, ClipboardCheck,
  ClipboardList, Clock, Flag, Flame, FileText, GraduationCap, Hammer, Inbox, Info, LayoutDashboard, LogOut,
  Map as MapIcon, Menu, PanelLeft, Rocket, ScrollText, Search, Sparkles, Target, TriangleAlert, Trophy,
  UserCheck, Users, X, Zap,
} from 'lucide';

/** Only the icons the app uses, so the bundle stays small. Add new icons here. */
export const ICONS = {
  ArrowRight, Bell, BookOpen, Briefcase, CalendarDays, ChartColumn, Check, ChevronDown, ChevronRight, ClipboardCheck,
  ClipboardList, Clock, Flag, Flame, FileText, GraduationCap, Hammer, Inbox, Info, LayoutDashboard, LogOut,
  Map: MapIcon, Menu, PanelLeft, Rocket, ScrollText, Search, Sparkles, Target, TriangleAlert, Trophy,
  UserCheck, Users, X, Zap,
};

export type IconName = keyof typeof ICONS;
