import { Component, computed, input } from '@angular/core';

@Component({
  selector: 'app-progress',
  template: `
    <div
      role="progressbar"
      [attr.aria-label]="label()"
      aria-valuemin="0"
      aria-valuemax="100"
      [attr.aria-valuenow]="clamped()"
      class="h-2 w-full overflow-hidden rounded-full bg-slate-100"
    >
      <div class="h-full rounded-full transition-all duration-500" [class]="barClass()" [style.width.%]="clamped()"></div>
    </div>
  `,
})
export class Progress {
  readonly value = input.required<number>();
  readonly label = input.required<string>();
  readonly tone = input<'brand' | 'success' | 'xp'>('brand');
  protected readonly clamped = computed(() => Math.min(100, Math.max(0, this.value())));
  protected readonly barClass = computed(
    () => ({ brand: 'bg-brand-600', success: 'bg-emerald-500', xp: 'bg-amber-500' })[this.tone()],
  );
}
