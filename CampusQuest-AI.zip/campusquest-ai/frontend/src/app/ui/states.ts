import { Component, input, output } from '@angular/core';
import { Icon } from './icon';

@Component({
  selector: 'app-empty-state',
  imports: [Icon],
  template: `
    <div class="card flex flex-col items-center gap-3 py-12 text-center">
      <span class="rounded-full bg-brand-50 p-3 text-brand-600"><app-icon name="Inbox" [size]="24" /></span>
      <h2 class="text-lg font-semibold text-slate-900">{{ title() }}</h2>
      <p class="max-w-md text-sm text-slate-600">{{ description() }}</p>
      <ng-content />
    </div>
  `,
})
export class EmptyState {
  readonly title = input.required<string>();
  readonly description = input.required<string>();
}

@Component({
  selector: 'app-error-state',
  imports: [Icon],
  template: `
    <div role="alert" class="card flex flex-col items-center gap-3 py-12 text-center">
      <span class="rounded-full bg-red-50 p-3 text-red-600"><app-icon name="TriangleAlert" [size]="24" /></span>
      <h2 class="text-lg font-semibold text-slate-900">Couldn't load this page</h2>
      <p class="max-w-md text-sm text-slate-600">{{ message() }}</p>
      <button type="button" class="btn btn-primary" (click)="retry.emit()">Try again</button>
    </div>
  `,
})
export class ErrorState {
  readonly message = input.required<string>();
  readonly retry = output<void>();
}
