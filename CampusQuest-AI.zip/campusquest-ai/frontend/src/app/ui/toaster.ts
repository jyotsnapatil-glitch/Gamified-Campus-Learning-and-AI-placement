import { Component, inject } from '@angular/core';
import { ToastService } from '../core/toast.service';
import { Icon } from './icon';

@Component({
  selector: 'app-toaster',
  imports: [Icon],
  template: `
    <div class="pointer-events-none fixed right-4 top-4 z-50 flex w-80 flex-col gap-2" aria-live="polite">
      @for (t of toast.toasts(); track t.id) {
        <div class="pointer-events-auto flex items-start gap-2 rounded-xl border bg-white p-3 text-sm shadow-lg"
             [class]="t.kind === 'success' ? 'border-emerald-200' : 'border-slate-200'">
          <app-icon [name]="t.kind === 'success' ? 'Check' : 'Info'" [size]="16" />
          <p class="flex-1">{{ t.message }}</p>
          <button type="button" aria-label="Dismiss" class="text-slate-400 hover:text-slate-700" (click)="toast.dismiss(t.id)">
            <app-icon name="X" [size]="14" />
          </button>
        </div>
      }
    </div>
  `,
})
export class Toaster {
  protected readonly toast = inject(ToastService);
}
